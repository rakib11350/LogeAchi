# LogeAchi — ফোন থেকে আসল APK বানানোর নিয়ম

এই প্রজেক্টে GitHub Actions workflow আছে। GitHub-এর cloud runner আগে React web app build করবে, তারপর Android assets-এ বসিয়ে আসল debug APK compile করবে। কোনো empty/placeholder APK তৈরি করা হয় না।

## ফোন থেকে

1. GitHub.com খুলে একটি নতুন repository তৈরি করুন (Private রাখলেও হবে)।
2. এই ZIP-এর ভিতরের **`loge/logeachi_android/` folder-এর সব ফাইল** repository-র root-এ upload করুন। `.github/workflows/build-apk.yml` অবশ্যই থাকতে হবে।
3. GitHub repository → **Actions** → **Build LogeAchi APK** খুলুন।
4. **Run workflow** → branch `main` → **Run workflow** চাপুন।
5. Build সফল হলে workflow run খুলুন।
6. নিচে **Artifacts** থেকে `LogeAchi-debug-apk` খুলে ZIP নিন।
7. ZIP extract করে `app-debug.apk` ফোনে install করুন।

## গুরুত্বপূর্ণ

- প্রথম build-এ কিছু সময় লাগতে পারে, কারণ React dependencies ও Android SDK packages cloud runner-এ প্রস্তুত হবে।
- এটি debug APK। Play Store-এর জন্য পরে signed release build প্রয়োজন।
- অনলাইন payment, backend/API, database, SMS/OTP ইত্যাদি আলাদা server/configuration চাইলে সেগুলো আলাদাভাবে সেট করতে হবে।

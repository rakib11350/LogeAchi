import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_SHOPS,
  INITIAL_USERS,
  INITIAL_ORDERS,
  INITIAL_COUPONS,
  INITIAL_NOTIFICATIONS,
  INITIAL_REVIEWS,
} from './src/data/initialData';
import { Category, Product, Shop, User, Order, Coupon, Notification, Review } from './src/types';

// In-Memory Database Store (with full state persistence during server runtime)
class MarketplaceDatabase {
  categories: Category[] = [...INITIAL_CATEGORIES];
  products: Product[] = [...INITIAL_PRODUCTS];
  shops: Shop[] = [...INITIAL_SHOPS];
  users: User[] = [...INITIAL_USERS];
  orders: Order[] = [...INITIAL_ORDERS];
  coupons: Coupon[] = [...INITIAL_COUPONS];
  notifications: Notification[] = [...INITIAL_NOTIFICATIONS];
  reviews: Review[] = [...INITIAL_REVIEWS];
  activeOtps: Map<string, { code: string; expiresAt: number }> = new Map();
  settings = {
    deliveryChargeInsideDhaka: 80,
    deliveryChargeOutsideDhaka: 130,
    rocketMerchantNumber: '01700-000000-8',
    bkashMerchantNumber: '01700-000000-1',
    nagadMerchantNumber: '01700-000000-2',
    supportPhone: '+880 1700-000000',
    supportEmail: 'support@logeachi.com',
    founderName: 'মোঃ রাকিব হাসান (Md. Rakib Hasan)',
    founderTitle: 'Founder & Owner — LogeAchi.com',
  };
}

const db = new MarketplaceDatabase();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // ==========================================
  // REST API ENDPOINTS
  // ==========================================

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      platform: 'LogeAchi.com API',
      brand: 'লগে আছি ডটকম',
      founder: db.settings.founderName,
      timestamp: new Date().toISOString(),
    });
  });

  // Settings
  app.get('/api/settings', (req, res) => {
    res.json(db.settings);
  });

  app.put('/api/settings', (req, res) => {
    db.settings = { ...db.settings, ...req.body };
    res.json({ success: true, settings: db.settings });
  });

  // 1. Authentication & OTP
  app.post('/api/auth/login', (req, res) => {
    const { emailOrPhone, password, role } = req.body;
    const user = db.users.find(
      (u) => (u.email.toLowerCase() === (emailOrPhone || '').toLowerCase() || u.phone === emailOrPhone)
    );

    if (!user) {
      return res.status(401).json({ error: 'User not found with this email or phone.' });
    }

    // Role override for easy multi-panel testing if requested
    if (role && role !== user.role && user.role === 'super_admin') {
      // Super admin can impersonate any role
      const impersonated = { ...user, role };
      return res.json({ user: impersonated, token: 'jwt-token-loge-' + user.id });
    }

    res.json({ user, token: 'jwt-token-loge-' + user.id });
  });

  app.post('/api/auth/register', (req, res) => {
    const { name, email, phone, role = 'customer', shopName, shopAddress } = req.body;

    if (!name || !email || !phone) {
      return res.status(400).json({ error: 'Name, email, and phone are required.' });
    }

    const existing = db.users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() || u.phone === phone
    );
    if (existing) {
      return res.status(400).json({ error: 'An account with this email or phone already exists.' });
    }

    const newUser: User = {
      id: 'user-' + Date.now(),
      name,
      email,
      phone,
      role,
      verified: false,
      walletBalance: 0,
      createdAt: new Date().toISOString(),
    };

    if (role === 'seller' && shopName) {
      const newShop: Shop = {
        id: 'shop-' + Date.now(),
        sellerId: newUser.id,
        name: shopName,
        slug: shopName.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        logo: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&auto=format&fit=crop&q=60',
        banner: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&auto=format&fit=crop&q=60',
        rating: 5.0,
        reviewsCount: 0,
        verified: false,
        phone,
        address: shopAddress || 'Dhaka, Bangladesh',
        district: 'Dhaka',
        description: `Official shop of ${shopName} on LogeAchi.com`,
        commissionRate: 8,
        totalSales: 0,
        totalOrders: 0,
        status: 'pending',
      };
      db.shops.push(newShop);
      newUser.shopId = newShop.id;
    }

    db.users.push(newUser);

    // Generate 6-digit OTP
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    db.activeOtps.set(phone, { code, expiresAt: Date.now() + 5 * 60 * 1000 });

    res.json({
      user: newUser,
      message: 'Registration initiated. OTP sent to phone number.',
      otpSimulationCode: code, // returned for friendly preview testing
    });
  });

  app.post('/api/auth/send-otp', (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'Phone number is required.' });

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    db.activeOtps.set(phone, { code, expiresAt: Date.now() + 5 * 60 * 1000 });

    res.json({
      success: true,
      message: `OTP sent to ${phone}`,
      otpSimulationCode: code,
    });
  });

  app.post('/api/auth/verify-otp', (req, res) => {
    const { phone, code } = req.body;
    const record = db.activeOtps.get(phone);

    // Allow universal testing code '123456' as well
    if (code === '123456' || (record && record.code === code && record.expiresAt > Date.now())) {
      const user = db.users.find((u) => u.phone === phone);
      if (user) {
        user.verified = true;
      }
      db.activeOtps.delete(phone);
      return res.json({ success: true, message: 'OTP verified successfully.', user });
    }

    res.status(400).json({ error: 'Invalid or expired OTP code. Please try again.' });
  });

  // 2. Categories & Subcategories
  app.get('/api/categories', (req, res) => {
    const sorted = [...db.categories].sort((a, b) => a.order - b.order);
    res.json(sorted);
  });

  app.post('/api/categories', (req, res) => {
    const { name, nameBn, icon, image, subcategories = [] } = req.body;
    const newCategory: Category = {
      id: 'cat-' + Date.now(),
      name,
      nameBn: nameBn || name,
      slug: name.toLowerCase().replace(/[^a-z0-9]/g, '-'),
      icon: icon || 'Tag',
      image: image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=500&auto=format&fit=crop&q=60',
      order: db.categories.length + 1,
      subcategories,
    };
    db.categories.push(newCategory);
    res.json(newCategory);
  });

  app.put('/api/categories/:id', (req, res) => {
    const { id } = req.params;
    const idx = db.categories.findIndex((c) => c.id === id);
    if (idx === -1) return res.status(404).json({ error: 'Category not found' });

    db.categories[idx] = { ...db.categories[idx], ...req.body };
    res.json(db.categories[idx]);
  });

  app.delete('/api/categories/:id', (req, res) => {
    const { id } = req.params;
    db.categories = db.categories.filter((c) => c.id !== id);
    res.json({ success: true });
  });

  // 3. Products
  app.get('/api/products', (req, res) => {
    const {
      categoryId,
      subcategoryId,
      sellerId,
      status,
      search,
      isFlashSale,
      isFeatured,
      sort,
      minPrice,
      maxPrice,
    } = req.query;

    let list = [...db.products];

    if (status) {
      list = list.filter((p) => p.status === status);
    } else {
      // Public default: show approved & active
      list = list.filter((p) => p.status === 'approved' || p.status === 'active');
    }

    if (categoryId) {
      list = list.filter((p) => p.categoryId === categoryId);
    }
    if (subcategoryId) {
      list = list.filter((p) => p.subcategoryId === subcategoryId);
    }
    if (sellerId) {
      list = list.filter((p) => p.sellerId === sellerId);
    }
    if (isFlashSale === 'true') {
      list = list.filter((p) => p.isFlashSale);
    }
    if (isFeatured === 'true') {
      list = list.filter((p) => p.isFeatured);
    }
    if (minPrice) {
      list = list.filter((p) => p.salePrice >= Number(minPrice));
    }
    if (maxPrice) {
      list = list.filter((p) => p.salePrice <= Number(maxPrice));
    }
    if (search) {
      const q = String(search).toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.nameBn.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.shopName.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }

    if (sort === 'price_asc') {
      list.sort((a, b) => a.salePrice - b.salePrice);
    } else if (sort === 'price_desc') {
      list.sort((a, b) => b.salePrice - a.salePrice);
    } else if (sort === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'popular') {
      list.sort((a, b) => b.soldCount - a.soldCount);
    } else {
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    res.json(list);
  });

  app.get('/api/products/:id', (req, res) => {
    const product = db.products.find((p) => p.id === req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  });

  app.post('/api/products', (req, res) => {
    const data = req.body;
    const regularPrice = Number(data.regularPrice) || 1000;
    const salePrice = Number(data.salePrice) || regularPrice;
    const discountPercent = regularPrice > salePrice ? Math.round(((regularPrice - salePrice) / regularPrice) * 100) : 0;

    const newProduct: Product = {
      id: 'prod-' + Date.now(),
      name: data.name || 'New Product',
      nameBn: data.nameBn || data.name || 'নতুন পণ্য',
      description: data.description || '',
      categoryId: data.categoryId || 'cat-fashion-men',
      subcategoryId: data.subcategoryId,
      brand: data.brand || 'LogeAchi Select',
      sku: data.sku || 'SKU-' + Date.now().toString().slice(-6),
      regularPrice,
      salePrice,
      discountPercent,
      wholesalePrice: Number(data.wholesalePrice) || Math.round(salePrice * 0.8),
      stock: Number(data.stock) || 10,
      images: Array.isArray(data.images) && data.images.length > 0 ? data.images : [
        'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80',
      ],
      videoUrl: data.videoUrl,
      variations: data.variations || {},
      size: data.size,
      color: data.color,
      weight: data.weight,
      dimensions: data.dimensions,
      shippingInfo: data.shippingInfo || 'Standard Delivery: ৳80 inside Dhaka, ৳130 outside Dhaka.',
      sellerId: data.sellerId || 'user-seller-1',
      shopName: data.shopName || 'Dhaka Heritage Weaves',
      rating: 5.0,
      reviewsCount: 0,
      soldCount: 0,
      status: data.requireApproval ? 'pending' : 'approved',
      isFeatured: !!data.isFeatured,
      isFlashSale: !!data.isFlashSale,
      createdAt: new Date().toISOString(),
    };

    db.products.unshift(newProduct);
    res.json(newProduct);
  });

  app.put('/api/products/:id', (req, res) => {
    const idx = db.products.findIndex((p) => p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Product not found' });

    db.products[idx] = { ...db.products[idx], ...req.body };
    res.json(db.products[idx]);
  });

  app.delete('/api/products/:id', (req, res) => {
    db.products = db.products.filter((p) => p.id !== req.params.id);
    res.json({ success: true });
  });

  // Reviews
  app.get('/api/products/:id/reviews', (req, res) => {
    const list = db.reviews.filter((r) => r.productId === req.params.id);
    res.json(list);
  });

  app.post('/api/products/:id/reviews', (req, res) => {
    const { userId, userName, rating, comment } = req.body;
    const newRev: Review = {
      id: 'rev-' + Date.now(),
      productId: req.params.id,
      userId: userId || 'user-customer-demo',
      userName: userName || 'Customer',
      rating: Number(rating) || 5,
      comment: comment || '',
      createdAt: new Date().toISOString(),
      verifiedPurchase: true,
    };
    db.reviews.unshift(newRev);

    // Update product rating
    const prod = db.products.find((p) => p.id === req.params.id);
    if (prod) {
      const prodReviews = db.reviews.filter((r) => r.productId === prod.id);
      const avg = prodReviews.reduce((sum, r) => sum + r.rating, 0) / prodReviews.length;
      prod.rating = Number(avg.toFixed(1));
      prod.reviewsCount = prodReviews.length;
    }

    res.json(newRev);
  });

  // 4. Orders
  app.get('/api/orders', (req, res) => {
    const { customerId, sellerId, status } = req.query;
    let list = [...db.orders];

    if (customerId) {
      list = list.filter((o) => o.customerId === customerId);
    }
    if (sellerId) {
      list = list.filter((o) => o.items.some((i) => i.sellerId === sellerId));
    }
    if (status) {
      list = list.filter((o) => o.orderStatus === status);
    }

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json(list);
  });

  app.get('/api/orders/:id', (req, res) => {
    const order = db.orders.find((o) => o.id === req.params.id || o.orderNumber === req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json(order);
  });

  app.post('/api/orders', (req, res) => {
    const {
      customerId,
      customerName,
      customerPhone,
      customerEmail,
      shippingAddress,
      items,
      paymentMethod,
      paymentPhone,
      paymentTransactionId,
      couponCode,
      resellerId,
      notes,
    } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }

    const subtotal = items.reduce((sum: number, item: any) => sum + item.price * item.quantity, 0);
    const isInsideDhaka = shippingAddress?.area === 'inside_dhaka';
    const deliveryCharge = isInsideDhaka ? db.settings.deliveryChargeInsideDhaka : db.settings.deliveryChargeOutsideDhaka;

    let discount = 0;
    if (couponCode) {
      const coupon = db.coupons.find(
        (c) => c.code.toUpperCase() === couponCode.toUpperCase() && c.isActive
      );
      if (coupon && subtotal >= coupon.minOrderValue) {
        if (coupon.discountType === 'percentage') {
          discount = Math.round((subtotal * coupon.discountValue) / 100);
          if (coupon.maxDiscount && discount > coupon.maxDiscount) {
            discount = coupon.maxDiscount;
          }
        } else {
          discount = coupon.discountValue;
        }
        coupon.usedCount += 1;
      }
    }

    const grandTotal = Math.max(0, subtotal + deliveryCharge - discount);
    const orderNumber = 'LA-' + new Date().getFullYear() + '-' + Math.floor(100000 + Math.random() * 900000);

    const newOrder: Order = {
      id: 'ord-' + Date.now(),
      orderNumber,
      customerId: customerId || 'user-customer-demo',
      customerName: customerName || shippingAddress?.fullName || 'Valued Customer',
      customerPhone: customerPhone || shippingAddress?.phone || '01700000000',
      customerEmail: customerEmail || 'customer@logeachi.com',
      shippingAddress: shippingAddress || {
        fullName: customerName,
        phone: customerPhone,
        address: 'Dhaka',
        area: 'inside_dhaka',
        city: 'Dhaka',
        district: 'Dhaka',
      },
      items,
      subtotal,
      deliveryCharge,
      discount,
      couponCode,
      grandTotal,
      paymentMethod: paymentMethod || 'cod',
      paymentStatus: paymentMethod === 'cod' ? 'unpaid' : 'paid',
      paymentPhone,
      paymentTransactionId: paymentTransactionId || (paymentMethod !== 'cod' ? 'TXN-' + Date.now() : undefined),
      orderStatus: 'placed',
      trackingEvents: [
        {
          status: 'placed',
          title: 'Order Placed',
          description: `Order ${orderNumber} placed on LogeAchi.com via ${String(paymentMethod).toUpperCase()}.`,
          timestamp: new Date().toISOString(),
        },
      ],
      resellerId,
      notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    db.orders.unshift(newOrder);

    // Update product stock and sold counter
    for (const item of items) {
      const prod = db.products.find((p) => p.id === item.productId);
      if (prod) {
        prod.stock = Math.max(0, prod.stock - item.quantity);
        prod.soldCount += item.quantity;
      }
    }

    // Add notification for customer
    db.notifications.unshift({
      id: 'notif-' + Date.now(),
      userId: newOrder.customerId,
      title: 'Order Placed Successfully!',
      message: `Your order #${newOrder.orderNumber} (৳${newOrder.grandTotal}) has been placed.`,
      type: 'order',
      read: false,
      createdAt: new Date().toISOString(),
    });

    res.json(newOrder);
  });

  app.put('/api/orders/:id/status', (req, res) => {
    const { status, note, location } = req.body;
    const order = db.orders.find((o) => o.id === req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    order.orderStatus = status;
    order.updatedAt = new Date().toISOString();

    const titles: Record<string, string> = {
      confirmed: 'Order Confirmed',
      processing: 'Packaging and Quality Check',
      shipped: 'Handed Over to Courier',
      out_for_delivery: 'Out for Final Delivery',
      delivered: 'Delivered Successfully',
      cancelled: 'Order Cancelled',
      returned: 'Order Returned',
    };

    order.trackingEvents.push({
      status,
      title: titles[status] || `Status updated to ${status}`,
      description: note || `Order updated to ${status} by LogeAchi Logistics.`,
      timestamp: new Date().toISOString(),
      location: location || 'Dhaka Logistics Hub',
    });

    if (status === 'delivered') {
      order.paymentStatus = 'paid';
    }

    res.json(order);
  });

  // 5. Coupons
  app.get('/api/coupons', (req, res) => {
    res.json(db.coupons);
  });

  app.post('/api/coupons', (req, res) => {
    const newCoupon: Coupon = {
      id: 'coup-' + Date.now(),
      code: req.body.code.toUpperCase(),
      discountType: req.body.discountType || 'percentage',
      discountValue: Number(req.body.discountValue) || 10,
      minOrderValue: Number(req.body.minOrderValue) || 1000,
      maxDiscount: req.body.maxDiscount ? Number(req.body.maxDiscount) : undefined,
      validUntil: req.body.validUntil || '2026-12-31',
      usageLimit: Number(req.body.usageLimit) || 1000,
      usedCount: 0,
      isActive: true,
    };
    db.coupons.push(newCoupon);
    res.json(newCoupon);
  });

  app.post('/api/cart/apply-coupon', (req, res) => {
    const { code, subtotal } = req.body;
    if (!code) return res.status(400).json({ error: 'Coupon code required' });

    const coupon = db.coupons.find(
      (c) => c.code.toUpperCase() === code.trim().toUpperCase() && c.isActive
    );

    if (!coupon) {
      return res.status(404).json({ error: 'Invalid or inactive coupon code.' });
    }

    if (subtotal < coupon.minOrderValue) {
      return res.status(400).json({
        error: `Minimum order value for ${coupon.code} is ৳${coupon.minOrderValue}. Your subtotal is ৳${subtotal}.`,
      });
    }

    let discount = 0;
    if (coupon.discountType === 'percentage') {
      discount = Math.round((subtotal * coupon.discountValue) / 100);
      if (coupon.maxDiscount && discount > coupon.maxDiscount) {
        discount = coupon.maxDiscount;
      }
    } else {
      discount = coupon.discountValue;
    }

    res.json({
      valid: true,
      coupon,
      discount,
      message: `Coupon ${coupon.code} applied! You saved ৳${discount}.`,
    });
  });

  // 6. Shops & Sellers
  app.get('/api/shops', (req, res) => {
    res.json(db.shops);
  });

  app.get('/api/shops/:id', (req, res) => {
    const shop = db.shops.find((s) => s.id === req.params.id || s.slug === req.params.id);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });
    res.json(shop);
  });

  app.put('/api/shops/:id', (req, res) => {
    const idx = db.shops.findIndex((s) => s.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Shop not found' });
    db.shops[idx] = { ...db.shops[idx], ...req.body };
    res.json(db.shops[idx]);
  });

  // 7. Reseller Hub
  app.get('/api/reseller/catalog', (req, res) => {
    const products = db.products.filter((p) => p.status === 'approved' || p.status === 'active');
    res.json(products);
  });

  app.get('/api/reseller/stats', (req, res) => {
    const ordersWithReseller = db.orders.filter((o) => o.resellerId);
    const totalProfit = ordersWithReseller.reduce((sum, o) => sum + (o.resellerProfit || 350), 0);

    res.json({
      totalOrders: ordersWithReseller.length + 18,
      totalProfit: totalProfit + 14850,
      walletBalance: 8200,
      pendingPayout: 2500,
      referralCode: 'LOGEACHI-RAKIB-77',
      teamCount: 6,
      teamEarnings: 4200,
    });
  });

  app.post('/api/reseller/withdraw', (req, res) => {
    const { amount, method, accountNumber } = req.body;
    res.json({
      success: true,
      message: `Withdrawal request of ৳${amount} via ${String(method).toUpperCase()} (${accountNumber}) submitted for Super Admin approval.`,
    });
  });

  // 8. Super Admin & Platform Metrics
  app.get('/api/admin/stats', (req, res) => {
    const totalGmv = db.orders.reduce((sum, o) => sum + o.grandTotal, 0) + 1250000;
    const pendingProducts = db.products.filter((p) => p.status === 'pending');
    const pendingSellers = db.shops.filter((s) => s.status === 'pending');

    res.json({
      totalGmv,
      totalOrders: db.orders.length + 420,
      totalProducts: db.products.length,
      totalSellers: db.shops.length,
      totalCustomers: db.users.filter((u) => u.role === 'customer').length + 850,
      totalResellers: db.users.filter((u) => u.role === 'reseller').length + 120,
      pendingProductApprovals: pendingProducts.length,
      pendingSellerApprovals: pendingSellers.length,
      revenueThisMonth: Math.round(totalGmv * 0.08),
    });
  });

  app.post('/api/admin/approve-product', (req, res) => {
    const { productId, approved, reason } = req.body;
    const prod = db.products.find((p) => p.id === productId);
    if (!prod) return res.status(404).json({ error: 'Product not found' });

    prod.status = approved ? 'approved' : 'rejected';
    res.json({ success: true, product: prod });
  });

  app.post('/api/admin/approve-seller', (req, res) => {
    const { shopId, approved } = req.body;
    const shop = db.shops.find((s) => s.id === shopId);
    if (!shop) return res.status(404).json({ error: 'Shop not found' });

    shop.status = approved ? 'approved' : 'suspended';
    shop.verified = approved;
    res.json({ success: true, shop });
  });

  // 9. Notifications
  app.get('/api/notifications', (req, res) => {
    const { userId } = req.query;
    const list = userId ? db.notifications.filter((n) => n.userId === userId) : db.notifications;
    res.json(list);
  });

  app.put('/api/notifications/:id/read', (req, res) => {
    const notif = db.notifications.find((n) => n.id === req.params.id);
    if (notif) notif.read = true;
    res.json({ success: true });
  });

  // ==========================================
  // VITE DEV & PROD MIDDLEWARE
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`LogeAchi.com Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

export type UserRole = 'customer' | 'seller' | 'reseller' | 'super_admin' | 'staff';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  verified: boolean;
  walletBalance: number;
  referralCode?: string;
  shopId?: string;
  createdAt: string;
}

export interface Shop {
  id: string;
  sellerId: string;
  name: string;
  slug: string;
  logo: string;
  banner: string;
  rating: number;
  reviewsCount: number;
  verified: boolean;
  phone: string;
  address: string;
  district: string;
  description: string;
  commissionRate: number; // e.g. 8%
  totalSales: number;
  totalOrders: number;
  status: 'pending' | 'approved' | 'suspended';
}

export interface Subcategory {
  id: string;
  name: string;
  nameBn: string;
  slug: string;
}

export interface Category {
  id: string;
  name: string;
  nameBn: string;
  slug: string;
  icon: string;
  image: string;
  order: number;
  subcategories: Subcategory[];
}

export type ProductStatus = 'pending' | 'approved' | 'rejected' | 'active' | 'inactive' | 'out_of_stock';

export interface ProductVariation {
  sizes?: string[];
  colors?: string[];
  weights?: string[];
}

export interface Product {
  id: string;
  name: string;
  nameBn: string;
  description: string;
  categoryId: string;
  subcategoryId?: string;
  brand: string;
  sku: string;
  regularPrice: number;
  salePrice: number;
  discountPercent: number;
  wholesalePrice: number; // Reseller purchase price
  stock: number;
  images: string[];
  videoUrl?: string;
  variations: ProductVariation;
  size?: string;
  color?: string;
  weight?: string;
  dimensions?: string;
  shippingInfo: string;
  sellerId: string;
  shopName: string;
  rating: number;
  reviewsCount: number;
  soldCount: number;
  status: ProductStatus;
  isFeatured?: boolean;
  isFlashSale?: boolean;
  flashSaleEndsAt?: string;
  createdAt: string;
}

export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
  selectedWeight?: string;
  resellerPrice?: number; // if ordered through a reseller
}

export type PaymentMethod = 'cod' | 'rocket' | 'bkash' | 'nagad' | 'card';
export type PaymentStatus = 'unpaid' | 'paid' | 'verifying' | 'failed';
export type OrderStatus = 'placed' | 'confirmed' | 'processing' | 'shipped' | 'out_for_delivery' | 'delivered' | 'cancelled' | 'returned';

export interface ShippingAddress {
  fullName: string;
  phone: string;
  altPhone?: string;
  address: string;
  area: 'inside_dhaka' | 'outside_dhaka';
  city: string;
  district: string;
  postalCode?: string;
  deliveryNotes?: string;
}

export interface TrackingEvent {
  status: OrderStatus;
  title: string;
  description: string;
  timestamp: string;
  location?: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  wholesalePrice?: number;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
  image: string;
  sellerId: string;
  shopName: string;
  subtotal: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  shippingAddress: ShippingAddress;
  items: OrderItem[];
  subtotal: number;
  deliveryCharge: number;
  discount: number;
  couponCode?: string;
  grandTotal: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paymentPhone?: string;
  paymentTransactionId?: string;
  orderStatus: OrderStatus;
  trackingEvents: TrackingEvent[];
  resellerId?: string;
  resellerProfit?: number;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  maxDiscount?: number;
  validUntil: string;
  usageLimit: number;
  usedCount: number;
  isActive: boolean;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'system' | 'wallet';
  read: boolean;
  createdAt: string;
  link?: string;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  createdAt: string;
  verifiedPurchase: boolean;
}

export interface ResellerTeam {
  id: string;
  name: string;
  leaderId: string;
  leaderName: string;
  inviteCode: string;
  membersCount: number;
  totalSales: number;
  totalCommission: number;
  createdAt: string;
}

export interface ResellerTeamMember {
  id: string;
  name: string;
  email: string;
  phone: string;
  joinedDate: string;
  totalSales: number;
  commissionEarned: number;
}

export interface ResellerProfile {
  id: string;
  userId: string;
  referralCode: string;
  totalOrders: number;
  totalProfit: number;
  walletBalance: number;
  pendingPayout: number;
  teamMembersCount: number;
  teamCommission: number;
  payoutMethod?: 'rocket' | 'bkash' | 'bank';
  payoutAccount?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userRole: 'seller' | 'reseller';
  amount: number;
  method: 'rocket' | 'bkash' | 'bank';
  accountDetails: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface PlatformStats {
  totalGmv: number;
  totalOrders: number;
  totalProducts: number;
  totalSellers: number;
  totalCustomers: number;
  totalResellers: number;
  pendingApprovals: number;
  revenueThisMonth: number;
}

import React, { useState } from 'react';
import {
  Share2,
  Users,
  Wallet,
  TrendingUp,
  Award,
  Copy,
  DollarSign,
  Package,
  Plus,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Check,
  ExternalLink,
} from 'lucide-react';
import { Product, ResellerTeam } from '../../types';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';

export const ResellerPanel: React.FC = () => {
  const {
    products,
    teams,
    currentUser,
    resellerWallet,
    requestPayout,
    createResellerTeam,
    joinResellerTeam,
    showToast,
    addToCart,
    setCustomerView,
    setActivePortal,
  } = useMarketplace();

  const [activeTab, setActiveTab] = useState<'catalog' | 'team' | 'wallet' | 'place_order'>('catalog');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Order on behalf of customer form state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(products[0] || null);
  const [resellerSellingPrice, setResellerSellingPrice] = useState<number>(
    products[0] ? products[0].salePrice + 400 : 2000
  );
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerArea, setCustomerArea] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');

  // Team creation state
  const [newTeamName, setNewTeamName] = useState('');
  const [showCreateTeam, setShowCreateTeam] = useState(false);

  // Active user's team
  const myTeam = teams.find((t) => t.id === currentUser.resellerTeamId) || teams[0];

  const handleCopyShareLink = (product: Product, margin: number) => {
    const finalPrice = product.wholesalePrice + margin;
    const shareUrl = `${window.location.origin}/?ref=${currentUser.id}&p=${product.id}&target=${finalPrice}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedId(product.id);
    showToast(`Share link copied with ৳${margin} reseller profit!`);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handlePlaceResellerOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;

    // Add to cart with reseller profit note and go directly to checkout
    addToCart(selectedProduct, 1);
    setActivePortal('customer');
    setCustomerView('cart');
    showToast(
      `Order prepared for ${customerName}. Profit of ৳${resellerSellingPrice - selectedProduct.wholesalePrice} will credit to your wallet upon delivery.`
    );
  };

  const handleCreateTeamSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim()) return;
    createResellerTeam(newTeamName.trim());
    setShowCreateTeam(false);
    showToast(`Team "${newTeamName}" created successfully!`);
  };

  return (
    <div id="reseller-panel-dashboard" className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      {/* Reseller Banner */}
      <div className="bg-gradient-to-r from-[#024724] via-[#046A38] to-[#024724] rounded-3xl p-6 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#FF6B00] text-white flex items-center justify-center font-black shadow-lg">
            <Share2 className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black">{currentUser.name} (Reseller Hub)</h1>
              <span className="bg-orange-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                Active Reseller
              </span>
            </div>
            <p className="text-xs text-emerald-100 bangla-text mt-0.5">
              হোলসেল মূল্যে পণ্য নিয়ে ফেসবুকে ও অনলাইনে বিক্রি করুন • কোনো ইনভেস্টমেন্ট ছাড়াই
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/20">
          <div>
            <span className="text-[10px] text-emerald-200 uppercase font-bold block">Profit Wallet</span>
            <Currency amount={resellerWallet.balance} className="text-xl font-black text-white" />
          </div>
          <button
            onClick={() => setActiveTab('wallet')}
            className="px-3.5 py-2 bg-[#FF6B00] hover:bg-[#E05E00] text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
          >
            Withdraw to Rocket
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-bold">
        {[
          { id: 'catalog', label: 'Wholesale Catalog & Social Share', icon: Package },
          { id: 'place_order', label: 'Place Customer Order (ড্রপশিপিং)', icon: Plus },
          { id: 'team', label: `Reseller Team: ${myTeam?.name || 'My Team'}`, icon: Users },
          { id: 'wallet', label: 'Earnings & Payouts', icon: Wallet },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
                isActive
                  ? 'bg-[#046A38] text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Wholesale Catalog & Social Share Tab */}
      {activeTab === 'catalog' && (
        <div className="space-y-4">
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 text-xs text-slate-700 flex items-center justify-between gap-4">
            <div>
              <span className="font-bold text-[#046A38] text-sm block">
                Wholesale Prices Unlocked for Resellers!
              </span>
              <p className="text-slate-600 mt-0.5">
                Each product below displays the direct factory wholesale price. Add your desired profit margin (e.g. ৳300-৳600) and share directly to your Facebook Page, TikTok, WhatsApp, or Instagram.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.map((prod) => {
              const defaultMargin = prod.salePrice - prod.wholesalePrice;
              const isCopied = copiedId === prod.id;

              return (
                <div
                  key={prod.id}
                  className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-100 mb-3">
                      <img
                        src={prod.images[0]}
                        alt={prod.name}
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute top-2 left-2 bg-[#046A38] text-white text-[10px] font-bold px-2 py-0.5 rounded">
                        Wholesale Rate
                      </span>
                    </div>

                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {prod.shopName}
                    </span>
                    <h3 className="font-bold text-sm text-slate-900 line-clamp-2 mt-0.5">
                      {prod.name}
                    </h3>

                    {/* Price Matrix */}
                    <div className="mt-3 p-3 bg-slate-50 rounded-xl space-y-1 text-xs">
                      <div className="flex justify-between text-slate-500">
                        <span>Wholesale (হোলসেল):</span>
                        <Currency amount={prod.wholesalePrice} className="font-bold text-slate-800" />
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Customer MRP:</span>
                        <Currency amount={prod.salePrice} className="line-through" />
                      </div>
                      <div className="flex justify-between text-[#046A38] font-bold pt-1 border-t border-slate-200">
                        <span>Potential Profit:</span>
                        <span>+<Currency amount={defaultMargin} /></span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleCopyShareLink(prod, defaultMargin)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
                        isCopied
                          ? 'bg-emerald-600 text-white'
                          : 'bg-[#046A38] hover:bg-[#024724] text-white'
                      }`}
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{isCopied ? 'Link Copied!' : 'Copy Share Link'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setSelectedProduct(prod);
                        setResellerSellingPrice(prod.wholesalePrice + 500);
                        setActiveTab('place_order');
                      }}
                      className="py-2 px-3 rounded-xl text-xs font-bold bg-orange-50 text-[#FF6B00] hover:bg-orange-100 border border-orange-200 transition-colors flex items-center justify-center gap-1"
                    >
                      <span>Order for Buyer</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. Place Customer Order on Behalf (Dropshipping) */}
      {activeTab === 'place_order' && selectedProduct && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
          <h2 className="text-xl font-black text-slate-900 mb-1">
            Place Dropship Order on Customer’s Behalf
          </h2>
          <p className="text-xs text-slate-500 mb-6 bangla-text">
            কাস্টমারের ঠিকানায় সরাসরি পণ্য পাঠাবে LogeAchi। ডেলিভারি সম্পন্ন হলে আপনার অতিরিক্ত লাভ স্বয়ংক্রিয়ভাবে ওয়ালেটে জমা হবে।
          </p>

          <form onSubmit={handlePlaceResellerOrder} className="space-y-6">
            {/* Selected Product Card */}
            <div className="p-4 bg-slate-50 rounded-2xl border flex items-center gap-4">
              <img
                src={selectedProduct.images[0]}
                alt=""
                className="w-16 h-16 rounded-xl object-cover"
              />
              <div className="flex-1 min-w-0 text-xs">
                <h4 className="font-bold text-slate-900 truncate">{selectedProduct.name}</h4>
                <p className="text-slate-400">Shop: {selectedProduct.shopName}</p>
                <div className="mt-1 text-slate-700">
                  Wholesale Cost: <Currency amount={selectedProduct.wholesalePrice} className="font-bold" />
                </div>
              </div>
            </div>

            {/* Profit Margin Setting */}
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl">
              <label className="text-xs font-bold text-[#046A38] uppercase block mb-1.5">
                Set Your Final Selling Price to Customer:
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min={selectedProduct.wholesalePrice}
                  value={resellerSellingPrice}
                  onChange={(e) => setResellerSellingPrice(Number(e.target.value))}
                  className="w-48 text-sm font-bold p-2.5 rounded-xl border border-emerald-300 bg-white"
                />
                <div className="text-xs text-emerald-800">
                  Your Net Profit:{' '}
                  <span className="text-base font-black text-[#046A38]">
                    ৳{Math.max(0, resellerSellingPrice - selectedProduct.wholesalePrice)}
                  </span>
                </div>
              </div>
            </div>

            {/* Customer Details Form */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-700 uppercase">Customer Shipping Details</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold block mb-1">Customer Full Name *</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Farhana Begum"
                    className="w-full text-xs p-2.5 rounded-xl border"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold block mb-1">Customer Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className="w-full text-xs p-2.5 rounded-xl border"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[11px] font-bold block mb-1">Delivery Destination *</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setCustomerArea('inside_dhaka')}
                      className={`p-2.5 rounded-xl border text-left text-xs ${
                        customerArea === 'inside_dhaka'
                          ? 'border-[#046A38] bg-emerald-50 text-[#046A38] font-bold'
                          : 'border-slate-200'
                      }`}
                    >
                      Inside Dhaka (৳80)
                    </button>
                    <button
                      type="button"
                      onClick={() => setCustomerArea('outside_dhaka')}
                      className={`p-2.5 rounded-xl border text-left text-xs ${
                        customerArea === 'outside_dhaka'
                          ? 'border-[#046A38] bg-emerald-50 text-[#046A38] font-bold'
                          : 'border-slate-200'
                      }`}
                    >
                      Outside Dhaka (৳130)
                    </button>
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[11px] font-bold block mb-1">Full Delivery Address *</label>
                  <input
                    type="text"
                    required
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="House, Road, Thana, District"
                    className="w-full text-xs p-2.5 rounded-xl border"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-[#FF6B00] hover:bg-[#E05E00] text-white font-bold text-sm rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
            >
              <span>Submit & Dispatch to Customer</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* 3. Reseller Team Tab */}
      {activeTab === 'team' && myTeam && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-black text-slate-900">{myTeam.name}</h2>
                  <span className="text-xs bg-purple-100 text-purple-800 font-bold px-2.5 py-0.5 rounded-full">
                    Team Code: {myTeam.inviteCode}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Team Leader: <strong>{myTeam.leaderName}</strong> • {myTeam.membersCount} Members
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(myTeam.inviteCode);
                    showToast(`Invite code ${myTeam.inviteCode} copied!`);
                  }}
                  className="px-3.5 py-2 border rounded-xl text-xs font-bold hover:bg-slate-50 flex items-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Team Code</span>
                </button>
              </div>
            </div>

            {/* Team Performance Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-6">
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                <span className="text-xs font-bold text-[#046A38] uppercase">Total Team Sales</span>
                <Currency amount={myTeam.totalSales} className="text-2xl font-black text-slate-900 mt-1" />
                <span className="text-[10px] text-slate-400 block mt-0.5">Overall volume</span>
              </div>

              <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                <span className="text-xs font-bold text-purple-700 uppercase">Team Bonus Pool</span>
                <Currency amount={myTeam.totalCommission} className="text-2xl font-black text-slate-900 mt-1" />
                <span className="text-[10px] text-slate-400 block mt-0.5">Distributed to members</span>
              </div>

              <div className="p-4 bg-orange-50 rounded-2xl border border-orange-100">
                <span className="text-xs font-bold text-[#FF6B00] uppercase">Monthly Target</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">84%</span>
                <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">On track for ৳10k bonus</span>
              </div>
            </div>

            {/* Leaderboard */}
            <div className="mt-2">
              <h3 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-500" />
                <span>Team Member Leaderboard</span>
              </h3>

              <div className="space-y-2">
                {[
                  { rank: 1, name: 'Tanvir Ahmed (Leader)', sales: '৳48,500', commission: '৳5,820', badge: '🥇' },
                  { rank: 2, name: 'Nusrat Jahan', sales: '৳32,100', commission: '৳3,850', badge: '🥈' },
                  { rank: 3, name: 'Sabbir Hossain', sales: '৳24,000', commission: '৳2,880', badge: '🥉' },
                  { rank: 4, name: 'Mehedi Hasan', sales: '৳15,400', commission: '৳1,840', badge: '' },
                ].map((m) => (
                  <div
                    key={m.rank}
                    className="p-3 bg-slate-50 rounded-xl flex items-center justify-between text-xs font-semibold"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 text-center font-bold text-slate-400">{m.badge || `#${m.rank}`}</span>
                      <span className="text-slate-800">{m.name}</span>
                    </div>
                    <div className="flex items-center gap-6">
                      <span className="text-slate-500">Sales: {m.sales}</span>
                      <span className="text-[#046A38] font-bold">Commission: {m.commission}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Wallet & Payout Tab */}
      {activeTab === 'wallet' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b">
            <div>
              <h2 className="text-xl font-black text-slate-900">Reseller Commission Wallet</h2>
              <p className="text-xs text-slate-400">Real-time dropshipping profits and team bonuses</p>
            </div>

            <button
              onClick={() => {
                requestPayout(resellerWallet.balance, 'rocket', '01700-000000-8');
                showToast(`Payout of ৳${resellerWallet.balance} requested to Rocket!`);
              }}
              className="px-5 py-3 bg-[#FF6B00] hover:bg-[#E05E00] text-white font-bold text-xs rounded-xl shadow-md"
            >
              Withdraw Entire Balance via Rocket
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-emerald-50 rounded-2xl">
              <span className="text-xs font-bold text-[#046A38] block uppercase">Current Balance</span>
              <Currency amount={resellerWallet.balance} className="text-2xl font-black text-slate-900 mt-1" />
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <span className="text-xs font-bold text-slate-500 block uppercase">Total Withdrawn</span>
              <Currency amount={resellerWallet.totalWithdrawn} className="text-2xl font-black text-slate-900 mt-1" />
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <span className="text-xs font-bold text-slate-500 block uppercase">Pending Clearance</span>
              <Currency amount={resellerWallet.pendingClearance} className="text-2xl font-black text-slate-900 mt-1" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

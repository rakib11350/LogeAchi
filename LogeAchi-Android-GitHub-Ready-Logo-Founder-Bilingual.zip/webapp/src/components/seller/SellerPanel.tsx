import React, { useState } from 'react';
import {
  Store,
  Package,
  ShoppingBag,
  DollarSign,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Truck,
  ArrowUpRight,
  ShieldCheck,
  TrendingUp,
  X,
  CreditCard,
  AlertCircle,
} from 'lucide-react';
import { Product, Order, OrderStatus } from '../../types';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';

export const SellerPanel: React.FC = () => {
  const {
    products,
    orders,
    shops,
    currentUser,
    addProduct,
    updateProduct,
    deleteProduct,
    updateOrderStatus,
    requestPayout,
    showToast,
  } = useMarketplace();

  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'payouts' | 'shop'>(
    'overview'
  );

  // Filter products belonging to this seller (or all for demo)
  const sellerProducts = products.filter(
    (p) => p.sellerId === currentUser.id || currentUser.role === 'super_admin'
  );

  // Filter orders containing items from this seller
  const sellerOrders = orders.filter((o) =>
    o.items.some((item) => item.sellerId === currentUser.id || currentUser.role === 'super_admin')
  );

  // Calculate earnings
  const totalSales = sellerOrders.reduce((sum, o) => sum + o.grandTotal, 0);
  const pendingOrdersCount = sellerOrders.filter((o) => o.orderStatus === 'placed' || o.orderStatus === 'processing').length;

  // Add Product Form State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProductName, setNewProductName] = useState('');
  const [newProductNameBn, setNewProductNameBn] = useState('');
  const [newCategory, setNewCategory] = useState('clothing');
  const [newRegularPrice, setNewRegularPrice] = useState(1500);
  const [newSalePrice, setNewSalePrice] = useState(1200);
  const [newWholesalePrice, setNewWholesalePrice] = useState(900);
  const [newStock, setNewStock] = useState(50);
  const [newBrand, setNewBrand] = useState('LogeAchi Select');
  const [newDesc, setNewDesc] = useState('High quality authentic product crafted in Bangladesh.');
  const [newImageUrl, setNewImageUrl] = useState(
    'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=600&auto=format&fit=crop&q=80'
  );

  // Payout Modal State
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState(5000);
  const [payoutMethod, setPayoutMethod] = useState<'rocket' | 'bkash' | 'nagad' | 'bank'>('rocket');
  const [payoutAccount, setPayoutAccount] = useState('01700-000000-8');

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName.trim()) return;

    await addProduct({
      name: newProductName,
      nameBn: newProductNameBn,
      slug: newProductName.toLowerCase().replace(/\s+/g, '-'),
      categoryId: newCategory,
      categorySlug: newCategory,
      regularPrice: Number(newRegularPrice),
      salePrice: Number(newSalePrice),
      wholesalePrice: Number(newWholesalePrice),
      stock: Number(newStock),
      brand: newBrand,
      description: newDesc,
      images: [newImageUrl],
      variations: { sizes: ['38', '40', '42'], colors: ['Navy', 'Black', 'Emerald'] },
      sku: `LA-${Math.floor(1000 + Math.random() * 9000)}`,
      sellerId: currentUser.id,
      shopId: 'shop-1',
      shopName: 'Dhaka Heritage Weaves',
      isFeatured: true,
      isFlashSale: false,
    });

    setShowAddModal(false);
    showToast('Product added successfully!');
  };

  const handleRequestPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    await requestPayout(payoutAmount, payoutMethod, payoutAccount);
    setShowPayoutModal(false);
  };

  return (
    <div id="seller-panel-dashboard" className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-[#024724] via-[#046A38] to-[#024724] rounded-3xl p-6 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
            <Store className="w-8 h-8 text-[#FF8C00]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black">Dhaka Heritage Weaves</h1>
              <span className="bg-emerald-400 text-slate-900 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                Verified Merchant
              </span>
            </div>
            <p className="text-xs text-emerald-100 bangla-text mt-0.5">
              লগে আছি ভেরিফাইড সেলার ড্যাশবোর্ড • শপ আইডি: SHOP-8291
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowPayoutModal(true)}
            className="px-4 py-2.5 bg-[#FF6B00] hover:bg-[#E05E00] text-white text-xs font-bold rounded-xl shadow-md transition-colors flex items-center gap-1.5"
          >
            <DollarSign className="w-4 h-4" />
            <span>Withdraw Earnings (Rocket / Bank)</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 bg-white text-[#046A38] hover:bg-emerald-50 text-xs font-bold rounded-xl shadow-md transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Product</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-bold">
        {[
          { id: 'overview', label: 'Overview & Stats', icon: TrendingUp },
          { id: 'products', label: `Products Catalog (${sellerProducts.length})`, icon: Package },
          { id: 'orders', label: `Customer Orders (${sellerOrders.length})`, icon: ShoppingBag },
          { id: 'payouts', label: 'Payouts & Rocket Wallet', icon: DollarSign },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
                isActive
                  ? 'bg-[#046A38] text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Total Gross Revenue</span>
              <Currency amount={totalSales} className="text-2xl font-black text-[#046A38] mt-1" />
              <span className="text-[10px] text-emerald-600 font-bold block mt-1">+18% from last week</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Available Balance</span>
              <Currency amount={totalSales * 0.95} className="text-2xl font-black text-[#FF6B00] mt-1" />
              <span className="text-[10px] text-slate-400 block mt-1">Ready for Rocket payout</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Total Orders</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">{sellerOrders.length}</span>
              <span className="text-[10px] text-amber-600 font-bold block mt-1">{pendingOrdersCount} awaiting dispatch</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Active Products</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">{sellerProducts.length}</span>
              <span className="text-[10px] text-emerald-600 font-bold block mt-1">All in active status</span>
            </div>
          </div>

          {/* Recent Orders to Process */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
            <h3 className="font-bold text-base text-slate-900 mb-4">Pending Seller Orders</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b">
                  <tr>
                    <th className="p-3">Order #</th>
                    <th className="p-3">Customer</th>
                    <th className="p-3">Area</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Payment</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sellerOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-slate-50/50">
                      <td className="p-3 font-mono font-bold text-[#046A38]">{order.orderNumber}</td>
                      <td className="p-3 font-bold text-slate-800">{order.customerName}</td>
                      <td className="p-3 text-slate-600">
                        {order.shippingAddress.area === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'}
                      </td>
                      <td className="p-3 font-bold">
                        <Currency amount={order.grandTotal} />
                      </td>
                      <td className="p-3 uppercase font-bold text-slate-700">
                        {order.paymentMethod}
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-amber-100 text-amber-800">
                          {order.orderStatus}
                        </span>
                      </td>
                      <td className="p-3">
                        {order.orderStatus === 'placed' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'confirmed')}
                            className="px-2.5 py-1 bg-[#046A38] text-white rounded-lg font-bold text-[10px]"
                          >
                            Accept Order
                          </button>
                        )}
                        {order.orderStatus === 'confirmed' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'processing')}
                            className="px-2.5 py-1 bg-[#FF6B00] text-white rounded-lg font-bold text-[10px]"
                          >
                            Package & Inspect
                          </button>
                        )}
                        {order.orderStatus === 'processing' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'shipped')}
                            className="px-2.5 py-1 bg-purple-600 text-white rounded-lg font-bold text-[10px]"
                          >
                            Hand to Courier
                          </button>
                        )}
                        {order.orderStatus === 'shipped' && (
                          <span className="text-slate-400 font-medium">In Transit</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. Products Tab */}
      {activeTab === 'products' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-base text-slate-900">Your Product Inventory</h3>
              <p className="text-xs text-slate-400">Manage pricing, wholesale discounts, stock, and variations</p>
            </div>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-[#046A38] text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Product</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sellerProducts.map((p) => (
              <div
                key={p.id}
                className="border border-slate-200 rounded-2xl p-4 flex gap-3 items-start bg-white shadow-2xs hover:shadow-xs transition-shadow"
              >
                <img
                  src={p.images[0]}
                  alt={p.name}
                  className="w-20 h-20 rounded-xl object-cover bg-slate-100 border"
                />
                <div className="flex-1 min-w-0 text-xs">
                  <h4 className="font-bold text-slate-900 truncate">{p.name}</h4>
                  <p className="text-slate-400 text-[10px]">SKU: {p.sku}</p>
                  <div className="mt-1 flex items-baseline gap-2">
                    <Currency amount={p.salePrice} className="font-bold text-[#046A38]" />
                    <span className="text-[10px] text-slate-400">
                      Wholesale: <Currency amount={p.wholesalePrice} />
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-medium">
                      Stock: {p.stock}
                    </span>
                    <button
                      onClick={() => deleteProduct(p.id)}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="Delete Product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Orders Tab */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-base text-slate-900">All Store Orders</h3>
          <div className="space-y-3">
            {sellerOrders.map((order) => (
              <div key={order.id} className="p-4 border rounded-2xl flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-[#046A38]">{order.orderNumber}</span>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase bg-slate-100">
                      {order.orderStatus}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Customer: <strong>{order.customerName}</strong> ({order.customerPhone})
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Address: {order.shippingAddress.address}, {order.shippingAddress.city}
                  </p>
                </div>

                <div className="text-right">
                  <Currency amount={order.grandTotal} className="text-base font-black text-slate-900" />
                  <span className="text-[10px] text-slate-400 block uppercase">
                    Method: {order.paymentMethod}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Payouts Tab */}
      {activeTab === 'payouts' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-base text-slate-900">Merchant Payout Requests</h3>
              <p className="text-xs text-slate-400">Receive merchant funds to DBBL Rocket, bKash, or Bank</p>
            </div>
            <button
              onClick={() => setShowPayoutModal(true)}
              className="px-4 py-2 bg-[#FF6B00] text-white text-xs font-bold rounded-xl"
            >
              Request Withdrawal
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-100 flex items-center gap-3">
            <CreditCard className="w-6 h-6 text-[#8B1874]" />
            <div>
              <h4 className="font-bold text-xs text-[#8B1874]">Rocket Instant Settlement</h4>
              <p className="text-[11px] text-slate-600">
                LogeAchi automatically settles verified merchant payouts via Rocket within 4 hours.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-xl rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b">
              <h3 className="font-black text-base text-slate-900">Add New Marketplace Product</h3>
              <button onClick={() => setShowAddModal(false)}><X className="w-4 h-4" /></button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3 text-xs">
              <div>
                <label className="font-bold block mb-1">Product Title (English) *</label>
                <input
                  type="text"
                  required
                  value={newProductName}
                  onChange={(e) => setNewProductName(e.target.value)}
                  placeholder="e.g. Pure Tangail Handloom Cotton Saree"
                  className="w-full p-2.5 rounded-xl border"
                />
              </div>

              <div>
                <label className="font-bold block mb-1">Product Title (Bangla) *</label>
                <input
                  type="text"
                  value={newProductNameBn}
                  onChange={(e) => setNewProductNameBn(e.target.value)}
                  placeholder="e.g. খাঁটি টাঙ্গাইল তাঁত সুতি শাড়ি"
                  className="w-full p-2.5 rounded-xl border bangla-text"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="font-bold block mb-1">Regular Price (৳)</label>
                  <input
                    type="number"
                    value={newRegularPrice}
                    onChange={(e) => setNewRegularPrice(Number(e.target.value))}
                    className="w-full p-2 rounded-xl border"
                  />
                </div>
                <div>
                  <label className="font-bold block mb-1">Sale Price (৳)</label>
                  <input
                    type="number"
                    value={newSalePrice}
                    onChange={(e) => setNewSalePrice(Number(e.target.value))}
                    className="w-full p-2 rounded-xl border"
                  />
                </div>
                <div>
                  <label className="font-bold block mb-1">Wholesale (৳)</label>
                  <input
                    type="number"
                    value={newWholesalePrice}
                    onChange={(e) => setNewWholesalePrice(Number(e.target.value))}
                    className="w-full p-2 rounded-xl border"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold block mb-1">Stock Quantity</label>
                  <input
                    type="number"
                    value={newStock}
                    onChange={(e) => setNewStock(Number(e.target.value))}
                    className="w-full p-2 rounded-xl border"
                  />
                </div>
                <div>
                  <label className="font-bold block mb-1">Brand</label>
                  <input
                    type="text"
                    value={newBrand}
                    onChange={(e) => setNewBrand(e.target.value)}
                    className="w-full p-2 rounded-xl border"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold block mb-1">Image URL</label>
                <input
                  type="url"
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  className="w-full p-2 rounded-xl border"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#046A38] text-white font-bold rounded-xl text-xs"
              >
                Save & Publish to Marketplace
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Payout Modal */}
      {showPayoutModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b">
              <h3 className="font-black text-base text-slate-900">Withdraw Merchant Earnings</h3>
              <button onClick={() => setShowPayoutModal(false)}><X className="w-4 h-4" /></button>
            </div>

            <form onSubmit={handleRequestPayout} className="space-y-3 text-xs">
              <div>
                <label className="font-bold block mb-1">Withdrawal Amount (৳ BDT)</label>
                <input
                  type="number"
                  value={payoutAmount}
                  onChange={(e) => setPayoutAmount(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border"
                />
              </div>

              <div>
                <label className="font-bold block mb-1">Payment Method</label>
                <select
                  value={payoutMethod}
                  onChange={(e) => setPayoutMethod(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border bg-white"
                >
                  <option value="rocket">Rocket (রকেট) - Instant</option>
                  <option value="bkash">bKash (বিকাশ)</option>
                  <option value="nagad">Nagad (নগদ)</option>
                  <option value="bank">Bank Wire Transfer</option>
                </select>
              </div>

              <div>
                <label className="font-bold block mb-1">Rocket / Account Number</label>
                <input
                  type="text"
                  value={payoutAccount}
                  onChange={(e) => setPayoutAccount(e.target.value)}
                  placeholder="01700-000000-8"
                  className="w-full p-2.5 rounded-xl border"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#FF6B00] text-white font-bold rounded-xl text-xs"
              >
                Confirm Payout Request
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

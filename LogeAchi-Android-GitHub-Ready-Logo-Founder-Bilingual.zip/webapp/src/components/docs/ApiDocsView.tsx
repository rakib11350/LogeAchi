import React, { useState } from 'react';
import { Database, Server, Code, Play, CheckCircle2, Shield, Rocket, ArrowRight } from 'lucide-react';
import { FounderBadge } from '../common/FounderBadge';

export const ApiDocsView: React.FC = () => {
  const [activeEndpoint, setActiveEndpoint] = useState('/api/products');
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const testEndpoints = [
    { method: 'GET', path: '/api/products', desc: 'List all marketplace products with stock, variations & ratings' },
    { method: 'GET', path: '/api/orders', desc: 'Fetch all customer & dropship orders with payment status' },
    { method: 'GET', path: '/api/categories', desc: 'List categories with Bengali and English taxonomy' },
    { method: 'GET', path: '/api/coupons', desc: 'Fetch active promo codes and discount rules' },
    { method: 'GET', path: '/api/shops', desc: 'Verified multi-vendor merchant storefronts' },
    { method: 'GET', path: '/api/reseller/teams', desc: 'Reseller teams, commission rates & member rosters' },
  ];

  const handleTestApi = async (path: string) => {
    setActiveEndpoint(path);
    setLoading(true);
    try {
      const res = await fetch(path);
      const data = await res.json();
      setApiResponse(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setApiResponse(JSON.stringify({ error: err.message }, null, 2));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="api-docs-view" className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Title */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <Server className="w-6 h-6 text-[#FF6B00]" />
          <h1 className="text-2xl sm:text-3xl font-black">
            LogeAchi.com System Architecture & API Hub
          </h1>
        </div>
        <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
          Full-stack Node.js + Express REST API engine with Bangladesh payment workflows (Rocket, bKash, Nagad, COD), dynamic delivery charge formulas, multi-vendor commission rules, and reseller dropshipping pipelines.
        </p>
      </div>

      {/* 3 Pillar Architecture Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 1. Payment Engine */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-[#8B1874] flex items-center justify-center font-black">
            🚀
          </div>
          <h3 className="font-bold text-sm text-slate-900">Rocket & MFS Gateway</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            DBBL Rocket merchant account <code>01700-000000-8</code> with real-time TxnID logging and automated reconciliation. Seamless fallback for bKash, Nagad, and Cash on Delivery.
          </p>
        </div>

        {/* 2. Delivery Charge Engine */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#046A38] flex items-center justify-center font-bold">
            ৳
          </div>
          <h3 className="font-bold text-sm text-slate-900">Delivery Charge Formula</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Strict geographic matrix calculation:
            <br />
            <code>Inside Dhaka Metropolitan = ৳80</code>
            <br />
            <code>Outside Dhaka (63 Districts) = ৳130</code>
            <br />
            Calculated and itemized separately in every order invoice.
          </p>
        </div>

        {/* 3. Multi-Vendor & Reseller Network */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-2xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF6B00] flex items-center justify-center font-bold">
            👥
          </div>
          <h3 className="font-bold text-sm text-slate-900">6-Tier RBAC Access</h3>
          <p className="text-xs text-slate-500 leading-relaxed">
            Role-based permissions for Customers, Verified Sellers, Resellers, Team Leaders, Staff/Ops, and Super Admin (Md. Rakib Hasan).
          </p>
        </div>
      </div>

      {/* Live Interactive API Tester */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <Code className="w-5 h-5 text-[#046A38]" />
              <span>Interactive REST API Explorer</span>
            </h3>
            <p className="text-xs text-slate-400">Click any endpoint to fire live request to server.ts</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Endpoint List */}
          <div className="lg:col-span-5 space-y-2">
            {testEndpoints.map((ep) => (
              <button
                key={ep.path}
                onClick={() => handleTestApi(ep.path)}
                className={`w-full text-left p-3 rounded-xl border text-xs transition-all flex items-center justify-between ${
                  activeEndpoint === ep.path
                    ? 'border-[#046A38] bg-emerald-50 text-[#046A38] font-bold ring-1 ring-[#046A38]'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="bg-slate-800 text-white font-mono text-[9px] px-1.5 py-0.5 rounded">
                      {ep.method}
                    </span>
                    <span className="font-mono">{ep.path}</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 font-normal">{ep.desc}</p>
                </div>
                <Play className="w-3.5 h-3.5 shrink-0 ml-2 text-slate-400" />
              </button>
            ))}
          </div>

          {/* Response Payload Viewer */}
          <div className="lg:col-span-7 bg-slate-950 rounded-2xl p-4 text-emerald-400 font-mono text-xs overflow-auto max-h-[380px] border border-slate-800 shadow-inner">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-[10px] text-slate-400">
              <span>Status: 200 OK</span>
              <span>Endpoint: {activeEndpoint}</span>
            </div>
            <pre className="mt-3 text-[11px] leading-relaxed whitespace-pre-wrap">
              {loading ? '// Fetching data from Express backend...' : apiResponse || '// Click an endpoint on the left to execute API query'}
            </pre>
          </div>
        </div>
      </div>

      {/* Founder Recognition Section */}
      <FounderBadge />
    </div>
  );
};

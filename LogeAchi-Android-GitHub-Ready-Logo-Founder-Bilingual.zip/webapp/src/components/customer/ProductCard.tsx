import React from 'react';
import { Heart, ShoppingBag, Store } from 'lucide-react';
import { Product } from '../../types';
import { Currency } from '../common/Currency';
import { RatingStars } from '../common/RatingStars';
import { useMarketplace } from '../../context/MarketplaceContext';

interface ProductCardProps {
  product: Product;
  onOpenDetail: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onOpenDetail }) => {
  const { addToCart, toggleWishlist, isInWishlist } = useMarketplace();
  const isWished = isInWishlist(product.id);

  return (
    <div
      id={`product-card-${product.id}`}
      className="group bg-white rounded-2xl border border-slate-200/80 hover:border-[#046A38]/30 shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col overflow-hidden relative"
    >
      {/* Top Image Container */}
      <div className="relative aspect-square w-full bg-slate-100 overflow-hidden cursor-pointer" onClick={() => onOpenDetail(product)}>
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Discount Badge */}
        {product.discountPercent > 0 && (
          <div className="absolute top-2.5 left-2.5 bg-[#FF6B00] text-white text-[11px] font-extrabold px-2 py-0.5 rounded-md shadow-xs">
            -{product.discountPercent}% OFF
          </div>
        )}

        {/* Flash Sale Tag */}
        {product.isFlashSale && (
          <div className="absolute top-2.5 right-11 bg-red-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs animate-pulse">
            ⚡ Flash Deal
          </div>
        )}

        {/* Wishlist Heart Button */}
        <button
          id={`btn-wishlist-${product.id}`}
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product);
          }}
          className={`absolute top-2.5 right-2.5 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-colors ${
            isWished ? 'bg-red-50 text-red-500' : 'bg-white/80 text-slate-600 hover:text-red-500 hover:bg-white'
          }`}
          aria-label="Add to Wishlist"
        >
          <Heart className={`w-4 h-4 ${isWished ? 'fill-red-500 text-red-500' : ''}`} />
        </button>

        {/* Stock Badge if low */}
        {product.stock <= 5 && product.stock > 0 && (
          <div className="absolute bottom-2 left-2 bg-amber-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded backdrop-blur-xs">
            Only {product.stock} left!
          </div>
        )}
      </div>

      {/* Product Content Details */}
      <div className="p-3.5 flex-1 flex flex-col justify-between">
        <div>
          {/* Shop / Seller Tag */}
          <div className="flex items-center gap-1 text-slate-400 text-[11px] mb-1">
            <Store className="w-3 h-3 text-[#046A38]" />
            <span className="truncate hover:text-[#046A38] font-medium cursor-pointer" onClick={() => onOpenDetail(product)}>
              {product.shopName}
            </span>
          </div>

          {/* Product Title */}
          <h3
            className="font-bold text-sm text-slate-800 line-clamp-2 hover:text-[#046A38] cursor-pointer transition-colors leading-snug"
            onClick={() => onOpenDetail(product)}
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Bengali Name Subtitle */}
          {product.nameBn && (
            <p className="text-[11px] text-slate-500 bangla-text truncate mt-0.5">
              {product.nameBn}
            </p>
          )}

          {/* Rating & Sold count */}
          <div className="flex items-center gap-1.5 mt-2">
            <RatingStars rating={product.rating} size="sm" />
            <span className="text-[11px] text-slate-400">
              ({product.reviewsCount})
            </span>
            {product.soldCount > 0 && (
              <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded font-medium ml-auto">
                {product.soldCount} sold
              </span>
            )}
          </div>
        </div>

        {/* Price & Action Button */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <Currency amount={product.salePrice} className="text-base font-extrabold text-[#046A38]" />
              {product.regularPrice > product.salePrice && (
                <Currency
                  amount={product.regularPrice}
                  className="text-xs text-slate-400 line-through font-normal"
                />
              )}
            </div>
          </div>

          <button
            id={`btn-add-cart-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product, 1);
            }}
            className="w-9 h-9 rounded-xl bg-[#046A38] hover:bg-[#024724] text-white flex items-center justify-center transition-colors shadow-xs hover:shadow"
            title="Add to Cart"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

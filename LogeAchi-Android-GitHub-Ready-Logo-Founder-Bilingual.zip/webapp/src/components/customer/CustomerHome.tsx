import React, { useState, useEffect } from 'react';
import {
  Zap,
  Flame,
  Star,
  Store,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Clock,
  Award,
} from 'lucide-react';
import { Product, Shop } from '../../types';
import { ProductCard } from './ProductCard';
import { FounderBadge } from '../common/FounderBadge';
import { useMarketplace } from '../../context/MarketplaceContext';

interface CustomerHomeProps {
  onOpenProductDetail: (product: Product) => void;
  onSelectCategory: (categorySlug: string) => void;
  onSelectShop: (shopId: string) => void;
}

export const CustomerHome: React.FC<CustomerHomeProps> = ({
  onOpenProductDetail,
  onSelectCategory,
  onSelectShop,
}) => {
  const { products, categories, shops, setCustomerView } = useMarketplace();

  // Flash Sale Timer State (Counts down hours:minutes:seconds)
  const [timeLeft, setTimeLeft] = useState({
    hours: 14,
    minutes: 32,
    seconds: 48,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 24, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const flashSaleProducts = products.filter((p) => p.isFlashSale);
  const featuredProducts = products.filter((p) => p.isFeatured);
  const popularProducts = [...products].sort((a, b) => b.soldCount - a.soldCount);
  const newArrivals = [...products].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div id="customer-home-content" className="space-y-10 pb-16">
      {/* 1. Hero Promo Banner Slider / Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-4">
        <div className="relative rounded-3xl overflow-hidden shadow-lg bg-gradient-to-r from-[#046A38] via-[#024724] to-[#046A38] text-white p-6 sm:p-12 border border-[#046A38]/30">
          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 bg-[#FF6B00] text-white text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-xs">
              <Zap className="w-3.5 h-3.5" />
              <span>LogeAchi Grand Marketplace Fest</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
              আপনার স্বপ্ন, আমাদের সাথে—
              <br />
              <span className="text-[#FF8C00]">লগে আছি।</span>
            </h1>

            <p className="text-sm sm:text-base text-emerald-100 max-w-xl leading-relaxed">
              Bangladesh’s verified multi-vendor e-commerce platform. Genuine Dhakai Jamdani, Premium Panjabi, Gadgets & Organic Essentials delivered right to your doorstep.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                id="btn-hero-shop-now"
                onClick={() => setCustomerView('categories')}
                className="px-6 py-3.5 bg-[#FF6B00] hover:bg-[#E05E00] text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-transform active:scale-98 flex items-center gap-2"
              >
                <span>Shop All Categories</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-xl border border-white/20 text-xs flex items-center gap-2">
                <span className="font-bold text-[#FF8C00]">Code: WELCOME100</span>
                <span className="text-white/80">for ৳100 discount!</span>
              </div>
            </div>
          </div>

          {/* Decorative Background Elements */}
          <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-20 pointer-events-none hidden lg:block bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-400 via-transparent to-transparent"></div>
        </div>
      </section>

      {/* 2. Value Proposition Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#E8F5E9] text-[#046A38] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-800">100% Verified Sellers</h4>
              <p className="text-[11px] text-slate-400">Authentic goods guaranteed</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FFF3E0] text-[#FF6B00] flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-800">Swift 64-District Delivery</h4>
              <p className="text-[11px] text-slate-400">Dhaka ৳80 / Outside ৳130</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-800">Rocket & COD Available</h4>
              <p className="text-[11px] text-slate-400">Instant mobile payments</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-800">7-Day Easy Return</h4>
              <p className="text-[11px] text-slate-400">Hassle-free guarantee</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Category Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-black text-slate-900">Explore Categories</h2>
            <p className="text-xs text-slate-500 bangla-text">পণ্য ক্যাটাগরি অনুসারে ব্রাউজ করুন</p>
          </div>
          <button
            onClick={() => setCustomerView('categories')}
            className="text-xs font-bold text-[#046A38] hover:underline flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.slug)}
              className="group bg-white rounded-2xl border border-slate-200/80 hover:border-[#046A38] p-3 text-center cursor-pointer shadow-2xs hover:shadow-md transition-all flex flex-col items-center justify-between"
            >
              <div className="w-14 h-14 rounded-full overflow-hidden bg-slate-100 mb-2 border border-slate-100 group-hover:scale-105 transition-transform">
                <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
              </div>
              <h3 className="font-bold text-xs text-slate-800 group-hover:text-[#046A38] transition-colors line-clamp-1">
                {cat.name}
              </h3>
              <span className="text-[10px] text-slate-400 bangla-text truncate w-full">
                {cat.nameBn}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Flash Sale / Deals Section with Live Countdown */}
      {flashSaleProducts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="bg-gradient-to-r from-orange-50 via-white to-orange-50 rounded-3xl border border-orange-200 p-5 sm:p-7 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-orange-200/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-[#FF6B00] text-white flex items-center justify-center shadow-md animate-bounce">
                  <Flame className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                      Flash Sale Deals
                    </h2>
                    <span className="bg-red-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase">
                      Limited Time
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 bangla-text">
                    সর্বোচ্চ ছাড়ে এখনই লুফে নিন বিশেষ পণ্যসমূহ!
                  </p>
                </div>
              </div>

              {/* Countdown Clocks */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600 mr-1 flex items-center gap-1">
                  <Clock className="w-4 h-4 text-[#FF6B00]" />
                  <span>Ends In:</span>
                </span>
                <div className="flex items-center gap-1 text-xs font-mono font-black text-white">
                  <span className="bg-slate-900 px-2.5 py-1.5 rounded-lg shadow-xs">
                    {String(timeLeft.hours).padStart(2, '0')}
                  </span>
                  <span className="text-slate-900 font-bold">:</span>
                  <span className="bg-slate-900 px-2.5 py-1.5 rounded-lg shadow-xs">
                    {String(timeLeft.minutes).padStart(2, '0')}
                  </span>
                  <span className="text-slate-900 font-bold">:</span>
                  <span className="bg-[#FF6B00] px-2.5 py-1.5 rounded-lg shadow-xs">
                    {String(timeLeft.seconds).padStart(2, '0')}
                  </span>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {flashSaleProducts.map((prod) => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  onOpenDetail={onOpenProductDetail}
                />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 5. Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#046A38]" />
            <div>
              <h2 className="text-xl font-black text-slate-900">Featured Products</h2>
              <p className="text-xs text-slate-500 bangla-text">লগে আছি সেরা নির্বাচিত কালেকশন</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {featuredProducts.map((prod) => (
            <ProductCard
              key={prod.id}
              product={prod}
              onOpenDetail={onOpenProductDetail}
            />
          ))}
        </div>
      </section>

      {/* 6. Verified Seller Shops Spotlight */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-[#046A38]" />
            <div>
              <h2 className="text-xl font-black text-slate-900">Top Verified Sellers & Shops</h2>
              <p className="text-xs text-slate-500 bangla-text">বিশ্বস্ত শপসমূহ থেকে সরাসরি কিনুন</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {shops.map((shop) => (
            <div
              key={shop.id}
              onClick={() => onSelectShop(shop.id)}
              className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-center gap-3 mb-3">
                <img
                  src={shop.logo}
                  alt={shop.name}
                  className="w-12 h-12 rounded-xl object-cover border border-slate-100 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-bold text-sm text-slate-900 truncate">{shop.name}</h3>
                    {shop.verified && (
                      <ShieldCheck className="w-4 h-4 text-[#046A38] shrink-0" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 truncate">{shop.address}</p>
                </div>
              </div>

              <p className="text-xs text-slate-500 line-clamp-2 mb-3 leading-relaxed">
                {shop.description}
              </p>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1 text-amber-500 font-bold">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span>{shop.rating}</span>
                  <span className="text-slate-400 font-normal">({shop.reviewsCount})</span>
                </div>
                <span className="text-xs font-bold text-[#046A38] hover:underline">
                  Visit Store →
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. Popular Products & New Arrivals */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#FF6B00]" />
            <div>
              <h2 className="text-xl font-black text-slate-900">Popular & New Arrivals</h2>
              <p className="text-xs text-slate-500 bangla-text">সর্বাধিক বিক্রিত ও সাম্প্রতিক পণ্য</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {popularProducts.slice(0, 8).map((prod) => (
            <ProductCard
              key={prod.id}
              product={prod}
              onOpenDetail={onOpenProductDetail}
            />
          ))}
        </div>
      </section>

      {/* 8. Founder & Slogan Trust Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <FounderBadge />
      </section>
    </div>
  );
};

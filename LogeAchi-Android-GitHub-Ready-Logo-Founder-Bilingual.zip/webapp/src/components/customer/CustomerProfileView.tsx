import React from 'react';
import { User, Phone, Mail, MapPin, Wallet, Package, Heart, LogOut, ShieldCheck } from 'lucide-react';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';

interface CustomerProfileViewProps {
  onViewOrders: () => void;
  onViewWishlist: () => void;
}

export const CustomerProfileView: React.FC<CustomerProfileViewProps> = ({
  onViewOrders,
  onViewWishlist,
}) => {
  const { currentUser, orders, wishlist, logout, showToast } = useMarketplace();

  return (
    <div id="customer-profile-view" className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        {/* Profile Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80'}
              alt={currentUser.name}
              className="w-16 h-16 rounded-full object-cover border-4 border-[#046A38]/20"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-black text-slate-900">{currentUser.name}</h1>
                <span className="text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  {currentUser.role}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{currentUser.email}</p>
              <p className="text-xs text-slate-600 font-mono">{currentUser.phone}</p>
            </div>
          </div>

          <button
            onClick={() => {
              logout();
              showToast('Logged out successfully.');
            }}
            className="px-4 py-2 border border-rose-200 hover:bg-rose-50 text-rose-600 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>

        {/* Dashboard Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-6">
          <div
            onClick={onViewOrders}
            className="p-4 bg-emerald-50/70 border border-emerald-100 rounded-2xl cursor-pointer hover:bg-emerald-100/70 transition-colors"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-[#046A38]">Total Orders</span>
              <Package className="w-4 h-4 text-[#046A38]" />
            </div>
            <span className="text-2xl font-black text-slate-900">{orders.length}</span>
            <span className="text-[11px] text-slate-500 block mt-0.5">Click to view history</span>
          </div>

          <div
            onClick={onViewWishlist}
            className="p-4 bg-red-50/60 border border-red-100 rounded-2xl cursor-pointer hover:bg-red-100/60 transition-colors"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-red-600">Wishlist Items</span>
              <Heart className="w-4 h-4 text-red-500" />
            </div>
            <span className="text-2xl font-black text-slate-900">{wishlist.length}</span>
            <span className="text-[11px] text-slate-500 block mt-0.5">Saved favorite products</span>
          </div>

          <div className="p-4 bg-orange-50/60 border border-orange-100 rounded-2xl">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-[#FF6B00]">LogeAchi Wallet</span>
              <Wallet className="w-4 h-4 text-[#FF6B00]" />
            </div>
            <Currency amount={1500} className="text-2xl font-black text-slate-900" />
            <span className="text-[11px] text-slate-500 block mt-0.5">Cashback & Rewards</span>
          </div>
        </div>

        {/* Saved Addresses */}
        <div className="pt-4 border-t border-slate-100">
          <h3 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-[#046A38]" />
            <span>Saved Delivery Addresses</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">Home Address (Default)</span>
                <span className="text-[10px] bg-emerald-100 text-[#046A38] font-bold px-2 py-0.5 rounded">
                  Inside Dhaka
                </span>
              </div>
              <p className="text-slate-600">{currentUser.name}</p>
              <p className="text-slate-500">Flat 4B, Green Road, Dhanmondi, Dhaka</p>
              <p className="text-slate-400 font-mono">{currentUser.phone}</p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">Office / Work</span>
                <span className="text-[10px] bg-slate-200 text-slate-700 font-bold px-2 py-0.5 rounded">
                  Inside Dhaka
                </span>
              </div>
              <p className="text-slate-600">{currentUser.name}</p>
              <p className="text-slate-500">Level 8, Motijheel C/A, Dhaka 1000</p>
              <p className="text-slate-400 font-mono">{currentUser.phone}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

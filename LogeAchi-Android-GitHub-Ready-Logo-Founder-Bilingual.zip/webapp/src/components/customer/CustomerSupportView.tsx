import React, { useState } from 'react';
import {
  MessageSquare,
  Phone,
  Mail,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Send,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';

export const CustomerSupportView: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [chatMessages, setChatMessages] = useState<
    { sender: 'user' | 'agent'; text: string; time: string }[]
  >([
    {
      sender: 'agent',
      text: 'আসসালামু আলাইকুম! LogeAchi.com হেল্পডেস্কে আপনাকে স্বাগতম। কীভাবে সাহায্য করতে পারি?',
      time: 'Just now',
    },
  ]);
  const [inputMsg, setInputMsg] = useState('');

  const faqs = [
    {
      q: 'রকেট (Rocket) দিয়ে কীভাবে পেমেন্ট করবেন?',
      a: 'চেকআউটে Rocket নির্বাচন করুন। আপনার Rocket অ্যাপ বা *322# ডায়াল করে LogeAchi মার্চেন্ট নম্বর 01700-000000-8 এ মার্চেন্ট পে করুন। রেফারেন্স ঘরে LOGEACHI লিখুন। এরপর প্রাপ্ত TxnID ও একাউন্ট নম্বর চেকআউট ফরমে বসিয়ে অর্ডার কনফার্ম করুন।',
    },
    {
      q: 'ডেলিভারি চার্জ কত এবং কত দিনে ডেলিভারি পাওয়া যাবে?',
      a: 'ঢাকা মহানগরে ডেলিভারি চার্জ মাত্র ৳৮০ (২৪-৪৮ ঘণ্টার মধ্যে হোম ডেলিভারি)। ঢাকার বাইরে বাংলাদেশের যেকোনো জেলা ও উপজেলায় ডেলিভারি চার্জ ৳১৩০ (২-৪ কার্যদিবসের মধ্যে)।',
    },
    {
      q: 'ক্যাশ অন ডেলিভারিতে কি পণ্য দেখে মূল্য পরিশোধ করা যায়?',
      a: 'হ্যাঁ! আমাদের প্রতিটি কুরিয়ার পার্টনারের সাথে ওপেন বক্স সুবিধা রয়েছে। রাইডারের সামনে পার্সেলটি পরীক্ষা করে মূল্য পরিশোধ করতে পারেন।',
    },
    {
      q: 'আমি কীভাবে LogeAchi-তে সেলার বা রিসেলার হতে পারি?',
      a: 'খুবই সহজ! আমাদের উপরের মেনু থেকে "Seller Panel" বা "Reseller Hub" এ গিয়ে রেজিস্ট্রেশন সম্পন্ন করুন। আমাদের ভেরিফিকেশন টিম ২৪ ঘণ্টার মধ্যে শপ বা রিসেলার একাউন্ট সক্রিয় করে দেবে।',
    },
  ];

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;

    const userText = inputMsg.trim();
    const newMsg = {
      sender: 'user' as const,
      text: userText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, newMsg]);
    setInputMsg('');

    // Auto-reply
    setTimeout(() => {
      let reply =
        'ধন্যবাদ আপনার বার্তার জন্য! আমাদের কাস্টমার সাপোর্ট প্রতিনিধি দ্রুত আপনার সাথে যোগাযোগ করবেন। যেকোনো প্রয়োজনে আমাদের হটলাইন +880 1700-000000 এ কল করতে পারেন।';
      if (userText.toLowerCase().includes('rocket') || userText.toLowerCase().includes('রকেট')) {
        reply =
          'রকেট পেমেন্ট বিষয়ে: মার্চেন্ট নম্বর 01700-000000-8 এ পে করে ট্রানজেকশন আইডি (TxnID) দিয়ে দিন। আমরা তাৎক্ষণিক ভেরিফাই করে দেব!';
      } else if (userText.toLowerCase().includes('delivery') || userText.toLowerCase().includes('ডেলিভারি')) {
        reply =
          'ডেলিভারি সংক্রান্ত: ঢাকা সিটিতে ৳৮০ ও সারা বাংলাদেশে ৳১৩০। আপনার অর্ডার নাম্বার থাকলে দিন, আমি স্ট্যাটাস জানিয়ে দিচ্ছি।';
      }

      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'agent' as const,
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }, 600);
  };

  return (
    <div id="customer-support-view" className="max-w-5xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#046A38] to-[#024724] rounded-3xl p-6 sm:p-8 text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-md">
        <div>
          <span className="text-[11px] font-bold text-[#FF8C00] uppercase tracking-wider block mb-1">
            24/7 Dedicated Support
          </span>
          <h1 className="text-2xl sm:text-3xl font-black">
            LogeAchi Customer Care & Help
          </h1>
          <p className="text-xs text-emerald-100 bangla-text mt-1">
            আপনার যেকোনো প্রশ্ন, অর্ডার সমস্যা বা সহায়তায় আমরা সার্বক্ষণিক আছি আপনার লগে।
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <a
            href="tel:+8801700000000"
            className="px-4 py-2.5 bg-white text-[#046A38] rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-emerald-50 transition-colors shadow-xs"
          >
            <Phone className="w-4 h-4 text-[#FF6B00]" />
            <span>01700-000000</span>
          </a>
          <a
            href="mailto:support@logeachi.com"
            className="px-4 py-2.5 bg-[#FF6B00] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-[#E05E00] transition-colors shadow-xs"
          >
            <Mail className="w-4 h-4" />
            <span>Email Support</span>
          </a>
        </div>
      </div>

      {/* Main 2-Column: Live Chat & FAQs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left 7 cols: Live Chat Widget */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200/80 shadow-sm flex flex-col h-[520px] overflow-hidden">
          <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#046A38] text-white flex items-center justify-center">
                <MessageSquare className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-xs text-slate-900">LogeAchi Live Support Assistant</h3>
                <div className="flex items-center gap-1 text-[10px] text-emerald-600 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>Online & Ready to Help</span>
                </div>
              </div>
            </div>
            <span className="text-[10px] text-slate-400">Bangladesh</span>
          </div>

          {/* Chat Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50">
            {chatMessages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-2xl text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-[#046A38] text-white rounded-br-none shadow-xs'
                      : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none shadow-xs'
                  }`}
                >
                  <p>{msg.text}</p>
                </div>
                <span className="text-[9px] text-slate-400 mt-1 px-1">{msg.time}</span>
              </div>
            ))}
          </div>

          {/* Chat Input Form */}
          <form onSubmit={handleSendChat} className="p-3 border-t border-slate-100 bg-white flex gap-2">
            <input
              type="text"
              value={inputMsg}
              onChange={(e) => setInputMsg(e.target.value)}
              placeholder="Ask about Rocket, delivery, order status, or seller info..."
              className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
            />
            <button
              type="submit"
              className="px-4 py-2.5 bg-[#046A38] hover:bg-[#024724] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>
        </div>

        {/* Right 5 cols: FAQs Accordion */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5 mb-2">
            <HelpCircle className="w-4 h-4 text-[#046A38]" />
            <span>Frequently Asked Questions (FAQ)</span>
          </h3>

          <div className="space-y-2.5">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-2xl border border-slate-200/80 overflow-hidden shadow-2xs transition-all"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full text-left p-4 flex items-center justify-between gap-3 text-xs font-bold text-slate-800 hover:text-[#046A38] transition-colors"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-4 pb-4 text-xs text-slate-600 leading-relaxed bangla-text border-t border-slate-100 pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

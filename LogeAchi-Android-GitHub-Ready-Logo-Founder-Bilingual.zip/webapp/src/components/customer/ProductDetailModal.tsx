import React, { useState, useEffect } from 'react';
import {
  X,
  Heart,
  ShoppingBag,
  Truck,
  ShieldCheck,
  RotateCcw,
  Store,
  Star,
  Check,
  Share2,
} from 'lucide-react';
import { Product, Review } from '../../types';
import { Currency } from '../common/Currency';
import { RatingStars } from '../common/RatingStars';
import { useMarketplace } from '../../context/MarketplaceContext';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onBuyNow: (product: Product, options: { size?: string; color?: string; weight?: string; quantity: number }) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onBuyNow,
}) => {
  const { addToCart, toggleWishlist, isInWishlist, currentUser, showToast } = useMarketplace();

  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [selectedWeight, setSelectedWeight] = useState<string | undefined>(undefined);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'reviews' | 'shipping'>('description');

  // Reviews state
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    if (product) {
      setSelectedImageIdx(0);
      setSelectedSize(product.variations.sizes?.[0]);
      setSelectedColor(product.variations.colors?.[0]);
      setSelectedWeight(product.variations.weights?.[0]);
      setQuantity(1);

      // Fetch reviews
      fetch(`/api/products/${product.id}/reviews`)
        .then((r) => (r.ok ? r.json() : []))
        .then((data) => setReviews(data))
        .catch(() => {});
    }
  }, [product]);

  if (!product) return null;

  const isWished = isInWishlist(product.id);

  const handleAddToCart = () => {
    addToCart(product, quantity, {
      size: selectedSize,
      color: selectedColor,
      weight: selectedWeight,
    });
  };

  const handleBuyNow = () => {
    onBuyNow(product, {
      size: selectedSize,
      color: selectedColor,
      weight: selectedWeight,
      quantity,
    });
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    setSubmittingReview(true);
    try {
      const res = await fetch(`/api/products/${product.id}/reviews`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          userName: currentUser.name,
          rating: newRating,
          comment: newComment,
        }),
      });
      if (res.ok) {
        const addedReview = await res.json();
        setReviews([addedReview, ...reviews]);
        setNewComment('');
        showToast('Review submitted successfully! Thank you.');
      }
    } catch {
      showToast('Review saved.');
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div
      id="product-detail-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="product-detail-modal-card"
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header bar */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-slate-50/70">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#046A38]">
            <Store className="w-4 h-4" />
            <span>{product.shopName}</span>
            <span className="text-slate-300">•</span>
            <span className="text-slate-500 font-normal">SKU: {product.sku}</span>
          </div>

          <button
            id="btn-close-product-detail"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-300 text-slate-700 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto p-6 flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Column: Image Gallery */}
            <div className="flex flex-col gap-4">
              <div className="aspect-square w-full rounded-2xl bg-slate-100 overflow-hidden border border-slate-200 relative group">
                <img
                  src={product.images[selectedImageIdx] || product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {product.discountPercent > 0 && (
                  <div className="absolute top-3 left-3 bg-[#FF6B00] text-white text-xs font-extrabold px-2.5 py-1 rounded-lg shadow-md">
                    -{product.discountPercent}% OFF
                  </div>
                )}
              </div>

              {/* Thumbnails */}
              {product.images.length > 1 && (
                <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImageIdx(idx)}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                        selectedImageIdx === idx
                          ? 'border-[#046A38] scale-105 shadow-xs'
                          : 'border-slate-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Trust Badges */}
              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-100 text-center">
                <div className="p-2.5 rounded-xl bg-slate-50 flex flex-col items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-[#046A38] mb-1" />
                  <span className="text-[11px] font-bold text-slate-700">100% Genuine</span>
                  <span className="text-[10px] text-slate-400">Verified Seller</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 flex flex-col items-center justify-center">
                  <Truck className="w-5 h-5 text-[#FF6B00] mb-1" />
                  <span className="text-[11px] font-bold text-slate-700">Fast Delivery</span>
                  <span className="text-[10px] text-slate-400">Dhaka ৳80 / Out ৳130</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 flex flex-col items-center justify-center">
                  <RotateCcw className="w-5 h-5 text-emerald-600 mb-1" />
                  <span className="text-[11px] font-bold text-slate-700">Easy Returns</span>
                  <span className="text-[10px] text-slate-400">7 Days Return</span>
                </div>
              </div>
            </div>

            {/* Right Column: Details & Purchase Options */}
            <div className="flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#046A38] uppercase tracking-wider bg-emerald-50 px-2.5 py-0.5 rounded-full">
                    {product.brand}
                  </span>
                  <button
                    onClick={() => toggleWishlist(product)}
                    className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-red-500 transition-colors"
                  >
                    <Heart className={`w-4 h-4 ${isWished ? 'fill-red-500 text-red-500' : ''}`} />
                    <span>{isWished ? 'Saved' : 'Save'}</span>
                  </button>
                </div>

                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-2 leading-tight">
                  {product.name}
                </h1>

                {product.nameBn && (
                  <h2 className="text-sm font-semibold text-slate-500 bangla-text mt-1">
                    {product.nameBn}
                  </h2>
                )}

                {/* Rating & Reviews */}
                <div className="flex items-center gap-2 mt-3 pb-4 border-b border-slate-100">
                  <RatingStars rating={product.rating} size="md" />
                  <span className="text-sm font-bold text-slate-700">{product.rating}</span>
                  <span className="text-slate-300">•</span>
                  <button
                    onClick={() => setActiveTab('reviews')}
                    className="text-xs text-[#046A38] hover:underline font-semibold"
                  >
                    {product.reviewsCount} customer reviews
                  </button>
                  <span className="text-slate-300">•</span>
                  <span className="text-xs text-slate-500">{product.soldCount} sold</span>
                </div>

                {/* Price Display */}
                <div className="py-4 border-b border-slate-100">
                  <div className="flex items-baseline gap-3">
                    <Currency amount={product.salePrice} className="text-3xl font-black text-[#046A38]" />
                    {product.regularPrice > product.salePrice && (
                      <>
                        <Currency
                          amount={product.regularPrice}
                          className="text-base text-slate-400 line-through"
                        />
                        <span className="bg-[#FF6B00]/10 text-[#FF6B00] text-xs font-bold px-2 py-0.5 rounded">
                          Save ৳{product.regularPrice - product.salePrice} ({product.discountPercent}%)
                        </span>
                      </>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Inclusive of all local VAT & taxes.</p>
                </div>

                {/* Variations */}
                {/* Size options */}
                {product.variations.sizes && product.variations.sizes.length > 0 && (
                  <div className="mt-4">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                      Select Size: <span className="text-[#046A38]">{selectedSize}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {product.variations.sizes.map((s) => (
                        <button
                          key={s}
                          onClick={() => setSelectedSize(s)}
                          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                            selectedSize === s
                              ? 'border-[#046A38] bg-[#046A38] text-white shadow-xs'
                              : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Color options */}
                {product.variations.colors && product.variations.colors.length > 0 && (
                  <div className="mt-4">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                      Select Color: <span className="text-[#046A38]">{selectedColor}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {product.variations.colors.map((c) => (
                        <button
                          key={c}
                          onClick={() => setSelectedColor(c)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1.5 transition-all ${
                            selectedColor === c
                              ? 'border-[#FF6B00] bg-orange-50 text-[#FF6B00] ring-1 ring-[#FF6B00]'
                              : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                          }`}
                        >
                          {selectedColor === c && <Check className="w-3.5 h-3.5" />}
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Weight options */}
                {product.variations.weights && product.variations.weights.length > 0 && (
                  <div className="mt-4">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                      Package Size / Weight: <span className="text-[#046A38]">{selectedWeight}</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {product.variations.weights.map((w) => (
                        <button
                          key={w}
                          onClick={() => setSelectedWeight(w)}
                          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                            selectedWeight === w
                              ? 'border-[#046A38] bg-[#046A38] text-white'
                              : 'border-slate-200 bg-white text-slate-700'
                          }`}
                        >
                          {w}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity & Stock Status */}
                <div className="mt-5 flex items-center gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Quantity</label>
                    <div className="flex items-center border border-slate-200 rounded-xl bg-white overflow-hidden">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="px-3 py-1.5 hover:bg-slate-100 text-slate-600 font-bold"
                      >
                        -
                      </button>
                      <span className="px-3 py-1.5 text-sm font-bold text-slate-800 min-w-[32px] text-center">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                        className="px-3 py-1.5 hover:bg-slate-100 text-slate-600 font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="pt-5">
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                      In Stock ({product.stock} items available)
                    </span>
                  </div>
                </div>
              </div>

              {/* Call to Actions */}
              <div className="mt-8 pt-4 border-t border-slate-100 grid grid-cols-2 gap-3">
                <button
                  id="btn-modal-add-to-cart"
                  onClick={handleAddToCart}
                  className="py-3.5 px-4 rounded-xl border-2 border-[#046A38] text-[#046A38] hover:bg-[#046A38]/5 font-bold text-sm flex items-center justify-center gap-2 transition-colors"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Cart</span>
                </button>

                <button
                  id="btn-modal-buy-now"
                  onClick={handleBuyNow}
                  className="py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#FF6B00] to-[#E05E00] hover:brightness-105 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-transform active:scale-98"
                >
                  <span>Buy Now (অর্ডার করুন)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Bottom Tabs: Description, Reviews, Shipping */}
          <div className="mt-10 pt-6 border-t border-slate-200">
            <div className="flex items-center gap-6 border-b border-slate-200 pb-3">
              <button
                onClick={() => setActiveTab('description')}
                className={`text-sm font-bold pb-2 transition-all border-b-2 -mb-3.5 ${
                  activeTab === 'description'
                    ? 'border-[#046A38] text-[#046A38]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Product Description
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`text-sm font-bold pb-2 transition-all border-b-2 -mb-3.5 ${
                  activeTab === 'reviews'
                    ? 'border-[#046A38] text-[#046A38]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Customer Reviews ({reviews.length})
              </button>
              <button
                onClick={() => setActiveTab('shipping')}
                className={`text-sm font-bold pb-2 transition-all border-b-2 -mb-3.5 ${
                  activeTab === 'shipping'
                    ? 'border-[#046A38] text-[#046A38]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Shipping & Delivery
              </button>
            </div>

            {/* Tab Contents */}
            <div className="py-5 text-sm text-slate-600 leading-relaxed">
              {activeTab === 'description' && (
                <div className="space-y-4">
                  <p>{product.description}</p>
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
                    <h4 className="font-bold text-slate-800 mb-2">Specifications:</h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div><span className="text-slate-400">Brand:</span> {product.brand}</div>
                      <div><span className="text-slate-400">SKU:</span> {product.sku}</div>
                      <div><span className="text-slate-400">Category:</span> {product.categoryId}</div>
                      <div><span className="text-slate-400">Shop:</span> {product.shopName}</div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  {/* Write a review form */}
                  <form onSubmit={handleSubmitReview} className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <h4 className="font-bold text-slate-800 text-sm mb-2">Write a Customer Review</h4>
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xs text-slate-500">Your Rating:</span>
                      <RatingStars rating={newRating} interactive onRatingChange={setNewRating} size="md" />
                    </div>
                    <textarea
                      rows={3}
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Share your experience with this product..."
                      className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-[#046A38] bg-white mb-2"
                      required
                    />
                    <button
                      type="submit"
                      disabled={submittingReview}
                      className="px-4 py-2 bg-[#046A38] hover:bg-[#024724] text-white rounded-xl text-xs font-bold transition-colors"
                    >
                      {submittingReview ? 'Submitting...' : 'Submit Review'}
                    </button>
                  </form>

                  {/* Review List */}
                  <div className="space-y-3">
                    {reviews.length === 0 ? (
                      <p className="text-xs text-slate-400">No reviews yet. Be the first to review!</p>
                    ) : (
                      reviews.map((rev) => (
                        <div key={rev.id} className="p-3.5 bg-white border border-slate-200 rounded-xl">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-xs text-slate-800">{rev.userName}</span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(rev.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <RatingStars rating={rev.rating} size="sm" />
                          <p className="text-xs text-slate-600 mt-2">{rev.comment}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'shipping' && (
                <div className="space-y-3">
                  <div className="p-4 bg-emerald-50/60 border border-emerald-100 rounded-2xl">
                    <h4 className="font-bold text-[#046A38] text-sm mb-1">Delivery Charge Rates</h4>
                    <p className="text-xs text-slate-600">
                      • Inside Dhaka Metropolitan: <strong>৳80</strong> (Delivered in 24-48 hours)
                      <br />
                      • Outside Dhaka (All 63 Districts): <strong>৳130</strong> (Delivered in 2-4 business days)
                    </p>
                  </div>
                  <p className="text-xs text-slate-500">
                    Payment options available: <strong>Rocket</strong>, bKash, Nagad, and <strong>Cash on Delivery</strong>. You can inspect the package before paying the courier rider.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

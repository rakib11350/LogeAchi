import React, { useState } from 'react';
import { X, Lock, Mail, Phone, User as UserIcon, Shield, CheckCircle2, ArrowRight } from 'lucide-react';
import { UserRole } from '../../types';
import { BrandLogo } from '../common/BrandLogo';
import { useMarketplace } from '../../context/MarketplaceContext';

interface AuthModalProps {
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose }) => {
  const { login, register, verifyOtp, loginAsRole, showToast } = useMarketplace();

  const [mode, setMode] = useState<'login' | 'register' | 'otp'>('login');
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('password123');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('customer');
  const [otpCode, setOtpCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const res = await login(emailOrPhone, password);
      if (res.success) {
        onClose();
      } else {
        setErrorMsg(res.message || 'Invalid credentials');
      }
    } catch {
      setErrorMsg('Login failed. Try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const res = await register({
        name: fullName,
        email: emailOrPhone.includes('@') ? emailOrPhone : `${phone}@logeachi.com`,
        phone: phone || emailOrPhone,
        role: selectedRole,
        password,
      });

      if (res.success) {
        setMode('otp');
      } else {
        setErrorMsg(res.message || 'Registration failed');
      }
    } catch {
      setErrorMsg('Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const res = await verifyOtp(phone || emailOrPhone, otpCode || '123456');
      if (res.success) {
        showToast('Account verified successfully!');
        onClose();
      } else {
        setErrorMsg('Invalid OTP code. Use test code: 123456');
      }
    } catch {
      setErrorMsg('Verification failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      id="auth-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="auth-modal-card"
        className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden my-auto p-6 sm:p-8 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <BrandLogo size="sm" showTagline={false} />
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Demo Switcher */}
        <div className="my-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl">
          <span className="text-[11px] font-bold text-[#046A38] uppercase tracking-wider block mb-1.5">
            Instant Demo Logins:
          </span>
          <div className="grid grid-cols-3 gap-1.5 text-[10px] font-bold">
            <button
              onClick={() => {
                loginAsRole('customer');
                onClose();
              }}
              className="p-1.5 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-100 text-slate-800 text-center"
            >
              Customer
            </button>
            <button
              onClick={() => {
                loginAsRole('seller');
                onClose();
              }}
              className="p-1.5 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-100 text-slate-800 text-center"
            >
              Seller
            </button>
            <button
              onClick={() => {
                loginAsRole('reseller');
                onClose();
              }}
              className="p-1.5 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-100 text-slate-800 text-center"
            >
              Reseller
            </button>
            <button
              onClick={() => {
                loginAsRole('super_admin');
                onClose();
              }}
              className="p-1.5 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-100 text-slate-800 text-center col-span-2"
            >
              Super Admin (Md. Rakib Hasan)
            </button>
            <button
              onClick={() => {
                loginAsRole('staff');
                onClose();
              }}
              className="p-1.5 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-100 text-slate-800 text-center"
            >
              Staff
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 p-2.5 bg-rose-50 border border-rose-200 text-rose-600 text-xs rounded-xl font-medium">
            {errorMsg}
          </div>
        )}

        {/* 1. Login Mode */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Email or Phone Number
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={emailOrPhone}
                  onChange={(e) => setEmailOrPhone(e.target.value)}
                  placeholder="e.g. customer@logeachi.com"
                  className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Password</label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-[#046A38] hover:bg-[#024724] text-white font-bold text-xs rounded-xl shadow-md transition-colors"
            >
              {isLoading ? 'Signing In...' : 'Sign In'}
            </button>

            <div className="text-center text-xs text-slate-500 pt-2">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => setMode('register')}
                className="text-[#046A38] font-bold hover:underline"
              >
                Register Here
              </button>
            </div>
          </form>
        )}

        {/* 2. Register Mode */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3.5">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Register As</label>
              <div className="grid grid-cols-3 gap-2">
                {(['customer', 'seller', 'reseller'] as UserRole[]).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setSelectedRole(r)}
                    className={`py-1.5 px-2 rounded-xl text-xs font-bold capitalize border transition-all ${
                      selectedRole === r
                        ? 'border-[#046A38] bg-[#046A38] text-white'
                        : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Full Name</label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Your Full Name"
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-[#046A38]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Phone Number</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="01XXXXXXXXX"
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-[#046A38]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a strong password"
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:outline-[#046A38]"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-[#FF6B00] hover:bg-[#E05E00] text-white font-bold text-xs rounded-xl shadow-md transition-colors"
            >
              {isLoading ? 'Creating Account...' : 'Continue to OTP Verification'}
            </button>

            <div className="text-center text-xs text-slate-500 pt-1">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-[#046A38] font-bold hover:underline"
              >
                Sign In
              </button>
            </div>
          </form>
        )}

        {/* 3. OTP Verification Mode */}
        {mode === 'otp' && (
          <form onSubmit={handleVerifyOtp} className="space-y-4 text-center">
            <div className="w-12 h-12 mx-auto rounded-full bg-emerald-50 text-[#046A38] flex items-center justify-center">
              <Shield className="w-6 h-6" />
            </div>

            <h3 className="font-black text-slate-900 text-base">Enter 6-Digit OTP Code</h3>
            <p className="text-xs text-slate-500">
              We sent a verification SMS code to <strong>{phone || emailOrPhone}</strong>.
              <br />
              <span className="text-emerald-700 font-bold">(Universal Test OTP: 123456)</span>
            </p>

            <input
              type="text"
              maxLength={6}
              value={otpCode}
              onChange={(e) => setOtpCode(e.target.value)}
              placeholder="123456"
              className="w-48 mx-auto text-center text-xl font-mono tracking-widest py-2 rounded-xl border-2 border-[#046A38] focus:outline-none"
              required
            />

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-[#046A38] hover:bg-[#024724] text-white font-bold text-xs rounded-xl shadow-md transition-colors"
            >
              {isLoading ? 'Verifying...' : 'Verify & Complete'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

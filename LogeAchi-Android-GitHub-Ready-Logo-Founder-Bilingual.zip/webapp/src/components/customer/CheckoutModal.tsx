import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  MapPin,
  CreditCard,
  Truck,
  CheckCircle2,
  Info,
  Smartphone,
  Check,
} from 'lucide-react';
import { PaymentMethod, Order } from '../../types';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';

interface CheckoutModalProps {
  onClose: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  onClose,
  onOrderSuccess,
}) => {
  const {
    cart,
    cartSubtotal,
    deliveryCharge,
    shippingArea,
    setShippingArea,
    appliedCoupon,
    discountAmount,
    cartGrandTotal,
    currentUser,
    createOrder,
  } = useMarketplace();

  // Address State
  const [fullName, setFullName] = useState(currentUser.name || '');
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [altPhone, setAltPhone] = useState('');
  const [city, setCity] = useState(shippingArea === 'inside_dhaka' ? 'Dhaka' : 'Chittagong');
  const [district, setDistrict] = useState(shippingArea === 'inside_dhaka' ? 'Dhaka' : 'Chittagong');
  const [address, setAddress] = useState('Flat 4B, Green Road, Dhanmondi');
  const [deliveryNotes, setDeliveryNotes] = useState('');

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('rocket'); // Rocket as intended default/featured
  const [rocketAccount, setRocketAccount] = useState('01700000000');
  const [transactionId, setTransactionId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phone.trim() || !address.trim()) {
      setErrorMsg('Please complete your full name, phone number, and delivery address.');
      return;
    }

    if (paymentMethod === 'rocket' && !transactionId.trim()) {
      setErrorMsg('Please enter your Rocket Transaction ID (TxnID) after sending payment.');
      return;
    }

    if ((paymentMethod === 'bkash' || paymentMethod === 'nagad') && !transactionId.trim()) {
      setErrorMsg(`Please enter your ${paymentMethod.toUpperCase()} Transaction ID.`);
      return;
    }

    setErrorMsg(null);
    setIsSubmitting(true);

    try {
      const orderItems = cart.map((item) => ({
        productId: item.productId,
        name: item.product.name,
        price: item.product.salePrice,
        wholesalePrice: item.product.wholesalePrice,
        quantity: item.quantity,
        selectedSize: item.selectedSize,
        selectedColor: item.selectedColor,
        image: item.product.images[0],
        sellerId: item.product.sellerId,
        shopName: item.product.shopName,
        subtotal: item.product.salePrice * item.quantity,
      }));

      const payload = {
        customerId: currentUser.id,
        customerName: fullName,
        customerPhone: phone,
        customerEmail: currentUser.email,
        shippingAddress: {
          fullName,
          phone,
          altPhone,
          address,
          area: shippingArea,
          city,
          district,
          deliveryNotes,
        },
        items: orderItems,
        paymentMethod,
        paymentPhone: rocketAccount || phone,
        paymentTransactionId: transactionId || undefined,
        couponCode: appliedCoupon?.code,
        notes: deliveryNotes,
      };

      const newOrder = await createOrder(payload);
      onOrderSuccess(newOrder);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to place order. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="checkout-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="checkout-modal-card"
        className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between shrink-0 bg-slate-50">
          <div>
            <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <span>Checkout & Order Placement</span>
              <span className="text-xs font-semibold text-[#046A38] bg-emerald-50 px-2.5 py-0.5 rounded-full">
                LogeAchi.com
              </span>
            </h2>
            <p className="text-xs text-slate-500 bangla-text">
              নিরাপদ পেমেন্ট ও দ্রুত হোম ডেলিভারি।
            </p>
          </div>

          <button
            id="btn-close-checkout"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-300 text-slate-700 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmitOrder} className="overflow-y-auto p-6 space-y-6 flex-1">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium">
              {errorMsg}
            </div>
          )}

          {/* Section 1: Shipping Address */}
          <div>
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-[#046A38]" />
              <span>1. Shipping & Delivery Address</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Full Name (সম্পূর্ণ নাম) *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                  placeholder="e.g. Sabrina Akhter"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Contact Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                  placeholder="01XXXXXXXXX"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Delivery Area Selection *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShippingArea('inside_dhaka');
                      setDistrict('Dhaka');
                      setCity('Dhaka');
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      shippingArea === 'inside_dhaka'
                        ? 'border-[#046A38] bg-emerald-50 text-[#046A38] font-bold ring-1 ring-[#046A38]'
                        : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold">Inside Dhaka Metropolitan</div>
                    <div className="text-[11px] text-slate-500">Charge: ৳80</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShippingArea('outside_dhaka');
                      setDistrict('Chittagong');
                      setCity('Chittagong');
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      shippingArea === 'outside_dhaka'
                        ? 'border-[#046A38] bg-emerald-50 text-[#046A38] font-bold ring-1 ring-[#046A38]'
                        : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    <div className="text-xs font-bold">Outside Dhaka (All Districts)</div>
                    <div className="text-[11px] text-slate-500">Charge: ৳130</div>
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  District (জেলা) *
                </label>
                <input
                  type="text"
                  required
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Thana / City (থানা / শহর) *
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Full Street Address (বাসা/রোড/এলাকা) *
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                  placeholder="House, Road, Area details..."
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Delivery Notes / Instructions (Optional)
                </label>
                <input
                  type="text"
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-[#046A38]"
                  placeholder="e.g. Call before coming, leave with security"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Payment Selection */}
          <div className="pt-2 border-t border-slate-100">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-3">
              <CreditCard className="w-4 h-4 text-[#FF6B00]" />
              <span>2. Payment Method (পেমেন্ট পদ্ধতি)</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Rocket (Featured) */}
              <div
                id="payment-option-rocket"
                onClick={() => setPaymentMethod('rocket')}
                className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'rocket'
                    ? 'border-[#8B1874] bg-[#8B1874]/5 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#8B1874] text-white flex items-center justify-center font-black text-xs">
                      R
                    </div>
                    <span className="font-bold text-sm text-[#8B1874]">Rocket (রকেট)</span>
                  </div>
                  <span className="text-[10px] font-extrabold bg-[#8B1874] text-white px-2 py-0.5 rounded-full">
                    Featured
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  DBBL Rocket Mobile Banking payment. Instant verification.
                </p>
              </div>

              {/* Cash on Delivery (COD) */}
              <div
                id="payment-option-cod"
                onClick={() => setPaymentMethod('cod')}
                className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-[#046A38] bg-emerald-50/50 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#046A38] text-white flex items-center justify-center font-bold text-xs">
                      <Truck className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-sm text-[#046A38]">Cash on Delivery</span>
                  </div>
                  <span className="text-[10px] text-emerald-800 bg-emerald-100 font-bold px-2 py-0.5 rounded-full">
                    Doorstep
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Pay cash directly to courier rider upon receiving parcel.
                </p>
              </div>

              {/* bKash */}
              <div
                id="payment-option-bkash"
                onClick={() => setPaymentMethod('bkash')}
                className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'bkash'
                    ? 'border-[#E2136E] bg-pink-50/50 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#E2136E] text-white flex items-center justify-center font-bold text-xs">
                      b
                    </div>
                    <span className="font-bold text-sm text-[#E2136E]">bKash (বিকাশ)</span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  bKash Merchant Payment gateway.
                </p>
              </div>

              {/* Nagad */}
              <div
                id="payment-option-nagad"
                onClick={() => setPaymentMethod('nagad')}
                className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'nagad'
                    ? 'border-[#F7941D] bg-orange-50/50 shadow-sm'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#F7941D] text-white flex items-center justify-center font-bold text-xs">
                      N
                    </div>
                    <span className="font-bold text-sm text-[#F7941D]">Nagad (নগদ)</span>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Nagad Postal Mobile Banking.
                </p>
              </div>
            </div>

            {/* Rocket Step-by-Step Payment Instructions when Rocket is selected */}
            {paymentMethod === 'rocket' && (
              <div className="mt-4 p-4 rounded-2xl bg-[#8B1874]/5 border border-[#8B1874]/20 space-y-3">
                <div className="flex items-start gap-2.5">
                  <Info className="w-5 h-5 text-[#8B1874] shrink-0 mt-0.5" />
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <p className="font-bold text-[#8B1874]">Rocket Payment Instructions:</p>
                    <p className="mt-1">
                      1. Dial <strong>*322#</strong> or open your <strong>Rocket App</strong>.
                      <br />
                      2. Choose <strong>Merchant Pay</strong> and enter LogeAchi Merchant No:{' '}
                      <span className="font-mono font-bold text-[#8B1874] bg-white px-2 py-0.5 rounded border border-[#8B1874]/30">
                        01700-000000-8
                      </span>
                      <br />
                      3. Enter Amount: <strong><Currency amount={cartGrandTotal} /></strong> and Reference:{' '}
                      <strong>LOGEACHI</strong>
                      <br />
                      4. Enter your Rocket PIN to complete payment, then paste the <strong>TxnID</strong> below:
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">
                      Your Rocket Account Number *
                    </label>
                    <input
                      type="text"
                      value={rocketAccount}
                      onChange={(e) => setRocketAccount(e.target.value)}
                      placeholder="01XXXXXXXXX"
                      className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white focus:outline-[#8B1874]"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-slate-700 block mb-1">
                      Rocket Transaction ID (TxnID) *
                    </label>
                    <input
                      type="text"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      placeholder="e.g. RCK90182761"
                      className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white focus:outline-[#8B1874] font-mono uppercase"
                      required
                    />
                  </div>
                </div>
              </div>
            )}

            {/* bKash / Nagad Transaction ID input */}
            {(paymentMethod === 'bkash' || paymentMethod === 'nagad') && (
              <div className="mt-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Enter {paymentMethod.toUpperCase()} Transaction ID (TxnID) *
                </label>
                <input
                  type="text"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  placeholder="e.g. 9J82KH92L"
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono uppercase"
                  required
                />
              </div>
            )}
          </div>

          {/* Section 3: Final Breakdown Calculation */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2 text-xs">
            <h4 className="font-bold text-slate-800 text-sm mb-2">Payable Amount Calculation</h4>
            <div className="flex justify-between text-slate-600">
              <span>Product Subtotal</span>
              <Currency amount={cartSubtotal} className="font-semibold" />
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Delivery Charge ({shippingArea === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})</span>
              <Currency amount={deliveryCharge} className="font-semibold" />
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-[#FF6B00] font-semibold">
                <span>Coupon Discount ({appliedCoupon?.code})</span>
                <span>-<Currency amount={discountAmount} /></span>
              </div>
            )}
            <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline font-bold text-slate-900">
              <span className="text-sm">Final Payable Amount</span>
              <Currency amount={cartGrandTotal} className="text-xl text-[#046A38] font-black" />
            </div>
          </div>

          {/* Submit button */}
          <button
            id="btn-confirm-place-order"
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 bg-[#046A38] hover:bg-[#024724] text-white font-black text-base rounded-xl shadow-lg transition-transform active:scale-98 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <span>Processing Order...</span>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5 text-[#FF6B00]" />
                <span>Confirm Order (অর্ডার সম্পন্ন করুন)</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

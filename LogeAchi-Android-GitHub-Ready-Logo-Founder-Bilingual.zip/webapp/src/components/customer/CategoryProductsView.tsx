import React, { useState } from 'react';
import { Filter, SlidersHorizontal, ArrowUpDown, ChevronRight } from 'lucide-react';
import { Product } from '../../types';
import { ProductCard } from './ProductCard';
import { useMarketplace } from '../../context/MarketplaceContext';

interface CategoryProductsViewProps {
  onOpenDetail: (product: Product) => void;
  searchKeyword?: string;
}

export const CategoryProductsView: React.FC<CategoryProductsViewProps> = ({
  onOpenDetail,
  searchKeyword = '',
}) => {
  const { products, categories, selectedCategorySlug, setSelectedCategorySlug, setCustomerView } =
    useMarketplace();

  const [selectedSort, setSelectedSort] = useState<'popular' | 'price_low' | 'price_high' | 'newest'>('popular');
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(50000);
  const [selectedBrand, setSelectedBrand] = useState<string>('all');

  // Active Category details
  const activeCategory = categories.find((c) => c.slug === selectedCategorySlug);

  // Extract unique brands
  const brands = ['all', ...Array.from(new Set(products.map((p) => p.brand)))];

  // Filtering
  let filtered = products.filter((prod) => {
    // Category match
    if (selectedCategorySlug && prod.categorySlug !== selectedCategorySlug && prod.categoryId !== selectedCategorySlug) {
      return false;
    }
    // Search keyword
    if (searchKeyword.trim()) {
      const q = searchKeyword.toLowerCase();
      const matchName = prod.name.toLowerCase().includes(q);
      const matchNameBn = prod.nameBn?.toLowerCase().includes(q);
      const matchBrand = prod.brand.toLowerCase().includes(q);
      const matchDesc = prod.description.toLowerCase().includes(q);
      const matchFlash = q === 'flash' && prod.isFlashSale;
      if (!matchName && !matchNameBn && !matchBrand && !matchDesc && !matchFlash) {
        return false;
      }
    }
    // Price match
    if (prod.salePrice < minPrice || prod.salePrice > maxPrice) {
      return false;
    }
    // Brand match
    if (selectedBrand !== 'all' && prod.brand !== selectedBrand) {
      return false;
    }
    return true;
  });

  // Sorting
  filtered = [...filtered].sort((a, b) => {
    if (selectedSort === 'price_low') return a.salePrice - b.salePrice;
    if (selectedSort === 'price_high') return b.salePrice - a.salePrice;
    if (selectedSort === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    return b.soldCount - a.soldCount; // popular default
  });

  return (
    <div id="category-products-view" className="max-w-7xl mx-auto py-8 px-4 sm:px-6">
      {/* Category Header or Search Title */}
      <div className="mb-6 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
          <button onClick={() => setCustomerView('home')} className="hover:text-[#046A38]">
            Home
          </button>
          <ChevronRight className="w-3 h-3" />
          <span className="text-slate-700 font-semibold">
            {activeCategory ? activeCategory.name : searchKeyword ? `Search: "${searchKeyword}"` : 'All Products'}
          </span>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black text-slate-900">
              {activeCategory ? activeCategory.name : searchKeyword ? `Search Results for "${searchKeyword}"` : 'Marketplace Catalog'}
            </h1>
            {activeCategory && (
              <p className="text-xs text-slate-500 bangla-text mt-0.5">
                {activeCategory.nameBn} — {activeCategory.description}
              </p>
            )}
            <p className="text-xs text-slate-400 mt-1">{filtered.length} products found</p>
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-semibold hidden sm:inline">Sort by:</span>
            <select
              value={selectedSort}
              onChange={(e) => setSelectedSort(e.target.value as any)}
              className="text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 bg-white focus:outline-[#046A38]"
            >
              <option value="popular">Most Popular</option>
              <option value="price_low">Price: Low to High</option>
              <option value="price_high">Price: High to Low</option>
              <option value="newest">Newest Arrivals</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left 3 cols: Filters */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-2xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="font-bold text-xs text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#046A38]" />
                <span>Filters</span>
              </span>
              <button
                onClick={() => {
                  setSelectedCategorySlug(null);
                  setSelectedBrand('all');
                  setMinPrice(0);
                  setMaxPrice(50000);
                }}
                className="text-[11px] text-[#046A38] hover:underline font-bold"
              >
                Reset
              </button>
            </div>

            {/* Category Filter list */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Categories
              </h4>
              <div className="space-y-1 text-xs">
                <button
                  onClick={() => setSelectedCategorySlug(null)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg transition-colors ${
                    selectedCategorySlug === null
                      ? 'bg-[#046A38] text-white font-bold'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  All Categories
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedCategorySlug(c.slug)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg transition-colors flex items-center justify-between ${
                      selectedCategorySlug === c.slug
                        ? 'bg-[#046A38] text-white font-bold'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span className="truncate">{c.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Brand Filter */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Brand
              </h4>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full text-xs p-2 rounded-xl border border-slate-200 bg-white"
              >
                {brands.map((b) => (
                  <option key={b} value={b}>
                    {b === 'all' ? 'All Brands' : b}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Filter */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Price (৳ BDT)
              </h4>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={minPrice}
                  onChange={(e) => setMinPrice(Number(e.target.value))}
                  placeholder="Min"
                  className="w-full text-xs p-2 rounded-xl border border-slate-200"
                />
                <span className="text-slate-400 text-xs">-</span>
                <input
                  type="number"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  placeholder="Max"
                  className="w-full text-xs p-2 rounded-xl border border-slate-200"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right 9 cols: Products Grid */}
        <div className="lg:col-span-9">
          {filtered.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8">
              <h3 className="font-bold text-slate-800 text-base">No Products Found</h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Try adjusting your filters or search terms.
              </p>
              <button
                onClick={() => {
                  setSelectedCategorySlug(null);
                  setSelectedBrand('all');
                  setMinPrice(0);
                  setMaxPrice(50000);
                }}
                className="px-4 py-2 bg-[#046A38] text-white rounded-xl text-xs font-bold"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {filtered.map((prod) => (
                <ProductCard key={prod.id} product={prod} onOpenDetail={onOpenDetail} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

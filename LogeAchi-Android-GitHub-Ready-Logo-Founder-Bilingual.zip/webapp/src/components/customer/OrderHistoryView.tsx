import React, { useState } from 'react';
import { Package, Clock, Truck, ChevronRight, ShoppingBag } from 'lucide-react';
import { Order } from '../../types';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';

interface OrderHistoryViewProps {
  onSelectOrderToTrack: (orderId: string) => void;
  onStartShopping: () => void;
}

export const OrderHistoryView: React.FC<OrderHistoryViewProps> = ({
  onSelectOrderToTrack,
  onStartShopping,
}) => {
  const { orders, currentUser } = useMarketplace();
  const [filter, setFilter] = useState<'all' | 'active' | 'delivered'>('all');

  // Filter orders
  let filtered = orders;
  if (filter === 'active') {
    filtered = orders.filter((o) => o.orderStatus !== 'delivered' && o.orderStatus !== 'cancelled');
  } else if (filter === 'delivered') {
    filtered = orders.filter((o) => o.orderStatus === 'delivered');
  }

  if (orders.length === 0) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 text-center">
        <div className="w-16 h-16 mx-auto rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mb-4">
          <Package className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">No Orders Yet</h2>
        <p className="text-xs text-slate-500 mt-1 mb-6">
          When you place an order on LogeAchi.com, it will appear here.
        </p>
        <button
          onClick={onStartShopping}
          className="px-6 py-3 bg-[#046A38] text-white rounded-xl text-xs font-bold"
        >
          Explore Products
        </button>
      </div>
    );
  }

  return (
    <div id="order-history-view" className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Your Orders (অর্ডার ইতিহাস)</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Track, view invoice, and manage your e-commerce purchases.
          </p>
        </div>

        <div className="flex gap-1.5 bg-slate-100 p-1 rounded-xl text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              filter === 'all' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            All ({orders.length})
          </button>
          <button
            onClick={() => setFilter('active')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              filter === 'active' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            In Transit
          </button>
          <button
            onClick={() => setFilter('delivered')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              filter === 'delivered' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Delivered
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {filtered.map((order) => {
          const statusColors = {
            placed: 'bg-blue-50 text-blue-700 border-blue-200',
            confirmed: 'bg-indigo-50 text-indigo-700 border-indigo-200',
            processing: 'bg-amber-50 text-amber-700 border-amber-200',
            shipped: 'bg-purple-50 text-purple-700 border-purple-200',
            out_for_delivery: 'bg-orange-50 text-orange-700 border-orange-200',
            delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200',
            cancelled: 'bg-rose-50 text-rose-700 border-rose-200',
            returned: 'bg-slate-50 text-slate-700 border-slate-200',
          }[order.orderStatus];

          return (
            <div
              key={order.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-2xs hover:shadow-sm transition-all"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <span className="font-mono font-bold text-sm text-slate-900">
                    {order.orderNumber}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase border ${statusColors}`}
                  >
                    {order.orderStatus.replace('_', ' ')}
                  </span>
                </div>

                <div className="text-xs text-slate-400">
                  {new Date(order.createdAt).toLocaleDateString(undefined, {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </div>
              </div>

              {/* Items List */}
              <div className="py-3 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2 overflow-x-auto">
                  {order.items.map((item, idx) => (
                    <img
                      key={idx}
                      src={item.image}
                      alt={item.name}
                      title={item.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-100 bg-slate-50 shrink-0"
                    />
                  ))}
                  <div className="text-xs text-slate-600 pl-2">
                    <span className="font-bold">{order.items.length} item(s)</span>
                    <span className="text-slate-400 block text-[11px]">
                      via {order.paymentMethod.toUpperCase()}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs text-slate-400 block">Total</span>
                  <Currency amount={order.grandTotal} className="text-lg font-black text-[#046A38]" />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  {order.shippingAddress.address}, {order.shippingAddress.city}
                </span>

                <button
                  id={`btn-track-order-${order.id}`}
                  onClick={() => onSelectOrderToTrack(order.id)}
                  className="px-4 py-2 bg-[#046A38] hover:bg-[#024724] text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>Track Order</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

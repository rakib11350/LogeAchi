import React from 'react';
import { CheckCircle, Truck, PackageCheck, ArrowRight, Printer } from 'lucide-react';
import { Order } from '../../types';
import { Currency } from '../common/Currency';
import { BrandLogo } from '../common/BrandLogo';

interface OrderConfirmationModalProps {
  order: Order;
  onClose: () => void;
  onTrackOrder: (orderId: string) => void;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  onClose,
  onTrackOrder,
}) => {
  return (
    <div
      id="order-confirmation-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
    >
      <div
        id="order-confirmation-card"
        className="bg-white w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden my-auto p-6 sm:p-8 animate-in zoom-in-95 duration-200 text-center"
      >
        <div className="w-16 h-16 mx-auto rounded-full bg-[#E8F5E9] text-[#046A38] flex items-center justify-center mb-4">
          <CheckCircle className="w-10 h-10" />
        </div>

        <h2 className="text-2xl font-black text-slate-900">
          Order Placed Successfully!
        </h2>
        <p className="text-xs text-slate-500 bangla-text mt-1">
          লগে আছি ডটকমের সাথে কেনাকাটা করার জন্য ধন্যবাদ।
        </p>

        {/* Order Identifier Box */}
        <div className="mt-5 p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-left space-y-2 text-xs">
          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Order Number</span>
              <span className="font-mono font-bold text-sm text-[#046A38]">{order.orderNumber}</span>
            </div>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase">
              {order.paymentMethod.toUpperCase()} • {order.paymentStatus.toUpperCase()}
            </span>
          </div>

          <div className="flex justify-between text-slate-600">
            <span>Customer Name:</span>
            <span className="font-semibold text-slate-800">{order.customerName}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Delivery To:</span>
            <span className="font-semibold text-slate-800 text-right truncate max-w-[240px]">
              {order.shippingAddress.address}, {order.shippingAddress.city}
            </span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Delivery Charge:</span>
            <Currency amount={order.deliveryCharge} className="font-semibold text-slate-800" />
          </div>
          <div className="flex justify-between text-slate-900 font-bold pt-2 border-t border-slate-200">
            <span>Grand Total:</span>
            <Currency amount={order.grandTotal} className="text-base text-[#046A38]" />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <button
            id="btn-track-new-order"
            onClick={() => onTrackOrder(order.id)}
            className="flex-1 py-3 px-4 bg-[#046A38] hover:bg-[#024724] text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-colors"
          >
            <Truck className="w-4 h-4" />
            <span>Track Order (অর্ডার ট্র্যাক করুন)</span>
          </button>

          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl transition-colors"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
};

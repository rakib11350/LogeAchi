import React, { useState } from 'react';
import {
  Search,
  ShoppingBag,
  Heart,
  Bell,
  User as UserIcon,
  Menu,
  X,
  Truck,
  HelpCircle,
  Sparkles,
  Zap,
  Store,
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';
import { useMarketplace } from '../../context/MarketplaceContext';

interface CustomerHeaderProps {
  onOpenAuth: () => void;
  onOpenCart: () => void;
  onSearchChange?: (q: string) => void;
}

export const CustomerHeader: React.FC<CustomerHeaderProps> = ({
  onOpenAuth,
  onOpenCart,
  onSearchChange,
}) => {
  const {
    customerView,
    setCustomerView,
    cartCount,
    wishlist,
    unreadNotificationsCount,
    notifications,
    markNotificationRead,
    currentUser,
    setSelectedCategorySlug,
  } = useMarketplace();

  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearchChange) {
      onSearchChange(searchQuery);
    }
    setCustomerView('search');
  };

  return (
    <header className="sticky top-[37px] z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80">
      {/* Top Slogan Bar */}
      <div className="bg-gradient-to-r from-[#046A38] via-[#0B6E3F] to-[#046A38] text-white py-1 px-4 text-[11px] font-medium text-center bangla-text hidden sm:flex items-center justify-between">
        <div className="flex items-center gap-2 max-w-7xl mx-auto w-full justify-between">
          <span className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-[#FF8C00]" />
            <span>সারা দেশে ক্যাশ অন ডেলিভারি এবং রকেট পেমেন্ট উপলব্ধ!</span>
          </span>
          <span className="font-semibold text-emerald-100 hidden md:inline">
            “আপনার স্বপ্ন, আমাদের সাথে—লগে আছি।”
          </span>
          <span className="flex items-center gap-1 text-[10px] text-emerald-200">
            <span>হেল্পলাইন: +880 1700-000000</span>
          </span>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-4 sm:gap-8">
          {/* Brand Logo */}
          <div className="shrink-0">
            <BrandLogo
              size="md"
              showTagline={true}
              onClick={() => {
                setCustomerView('home');
                setSelectedCategorySlug(null);
              }}
            />
          </div>

          {/* Search Bar (Desktop) */}
          <form
            onSubmit={handleSearch}
            className="flex-1 max-w-xl hidden md:flex items-center relative"
          >
            <div className="relative w-full">
              <input
                id="search-input-desktop"
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (onSearchChange) onSearchChange(e.target.value);
                }}
                placeholder="Search Jamdani, Panjabi, Smartwatch, Honey, Gadgets..."
                className="w-full text-xs pl-10 pr-24 py-2.5 rounded-full border-2 border-[#046A38]/30 focus:border-[#046A38] bg-slate-50 focus:bg-white focus:outline-none transition-all shadow-2xs"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <button
                type="submit"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-[#046A38] hover:bg-[#024724] text-white text-xs font-bold px-4 py-1.5 rounded-full transition-colors"
              >
                Search
              </button>
            </div>
          </form>

          {/* Action Icons */}
          <div className="flex items-center gap-1.5 sm:gap-3">
            {/* Notifications Dropdown */}
            <div className="relative">
              <button
                id="btn-customer-notifications"
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-10 h-10 rounded-full hover:bg-slate-100 text-slate-700 flex items-center justify-center relative transition-colors"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadNotificationsCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#FF6B00] text-white text-[9px] font-extrabold flex items-center justify-center">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>

              {/* Notifications Popover */}
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 px-2 z-50 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between px-3 pb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-slate-800">Notifications</span>
                    <span className="text-[10px] text-slate-400">LogeAchi System</span>
                  </div>
                  <div className="max-h-64 overflow-y-auto py-1 space-y-1">
                    {notifications.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => markNotificationRead(n.id)}
                        className={`p-2.5 rounded-xl text-xs cursor-pointer transition-colors ${
                          n.read ? 'bg-white hover:bg-slate-50' : 'bg-emerald-50/70 font-semibold'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[#046A38] font-bold">{n.title}</span>
                          <span className="text-[9px] text-slate-400">
                            {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-0.5">{n.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Wishlist Button */}
            <button
              id="btn-customer-wishlist"
              onClick={() => setCustomerView('wishlist')}
              className="w-10 h-10 rounded-full hover:bg-slate-100 text-slate-700 flex items-center justify-center relative transition-colors hidden sm:flex"
              title="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              id="btn-customer-cart"
              onClick={onOpenCart}
              className="h-10 px-3.5 rounded-full bg-[#046A38] hover:bg-[#024724] text-white flex items-center gap-2 shadow-sm transition-all"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-[#FF6B00] text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="text-xs font-bold hidden sm:inline">Cart</span>
            </button>

            {/* User Account / Profile button */}
            <button
              id="btn-customer-profile"
              onClick={() => setCustomerView('profile')}
              className="flex items-center gap-2 pl-2 hover:opacity-80 transition-opacity"
            >
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80'}
                alt={currentUser.name}
                className="w-9 h-9 rounded-full object-cover border-2 border-[#046A38]"
              />
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="w-9 h-9 rounded-xl hover:bg-slate-100 text-slate-700 flex items-center justify-center md:hidden"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        <form onSubmit={handleSearch} className="mt-2.5 md:hidden">
          <div className="relative w-full">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (onSearchChange) onSearchChange(e.target.value);
              }}
              placeholder="Search in LogeAchi.com..."
              className="w-full text-xs pl-9 pr-20 py-2 rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <button
              type="submit"
              className="absolute right-1 top-1/2 -translate-y-1/2 bg-[#046A38] text-white text-[11px] font-bold px-3 py-1 rounded-full"
            >
              Search
            </button>
          </div>
        </form>

        {/* Sub Navigation Links */}
        <div className="hidden md:flex items-center justify-between mt-3 pt-2 border-t border-slate-100 text-xs font-semibold text-slate-600">
          <div className="flex items-center gap-6">
            <button
              onClick={() => {
                setCustomerView('home');
                setSelectedCategorySlug(null);
              }}
              className={`hover:text-[#046A38] transition-colors ${
                customerView === 'home' ? 'text-[#046A38] font-bold' : ''
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setCustomerView('categories')}
              className={`hover:text-[#046A38] transition-colors ${
                customerView === 'categories' ? 'text-[#046A38] font-bold' : ''
              }`}
            >
              All Categories
            </button>
            <button
              onClick={() => {
                setCustomerView('search');
                if (onSearchChange) onSearchChange('flash');
              }}
              className="hover:text-[#FF6B00] transition-colors flex items-center gap-1 text-[#FF6B00]"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Flash Deals</span>
            </button>
            <button
              onClick={() => setCustomerView('orders')}
              className={`hover:text-[#046A38] transition-colors ${
                customerView === 'orders' ? 'text-[#046A38] font-bold' : ''
              }`}
            >
              My Orders
            </button>
            <button
              onClick={() => setCustomerView('tracking')}
              className={`hover:text-[#046A38] transition-colors flex items-center gap-1 ${
                customerView === 'tracking' ? 'text-[#046A38] font-bold' : ''
              }`}
            >
              <Truck className="w-3.5 h-3.5 text-[#046A38]" />
              <span>Track Order</span>
            </button>
            <button
              onClick={() => setCustomerView('support')}
              className={`hover:text-[#046A38] transition-colors flex items-center gap-1 ${
                customerView === 'support' ? 'text-[#046A38] font-bold' : ''
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              <span>Customer Support</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAuth}
              className="text-[#046A38] hover:underline font-bold text-xs"
            >
              Seller / Reseller Portal Login
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 py-3 space-y-2 text-xs font-semibold text-slate-700 animate-in slide-in-from-top-2">
          <button
            onClick={() => {
              setCustomerView('home');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 hover:text-[#046A38]"
          >
            Home
          </button>
          <button
            onClick={() => {
              setCustomerView('categories');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 hover:text-[#046A38]"
          >
            Categories
          </button>
          <button
            onClick={() => {
              setCustomerView('orders');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 hover:text-[#046A38]"
          >
            My Orders
          </button>
          <button
            onClick={() => {
              setCustomerView('tracking');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 hover:text-[#046A38]"
          >
            Track Order
          </button>
          <button
            onClick={() => {
              setCustomerView('wishlist');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 hover:text-[#046A38]"
          >
            Wishlist ({wishlist.length})
          </button>
          <button
            onClick={() => {
              setCustomerView('support');
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 hover:text-[#046A38]"
          >
            Customer Support & FAQs
          </button>
        </div>
      )}
    </header>
  );
};

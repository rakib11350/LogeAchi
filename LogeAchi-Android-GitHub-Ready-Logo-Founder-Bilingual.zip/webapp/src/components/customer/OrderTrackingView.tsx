import React, { useState } from 'react';
import {
  PackageCheck,
  Truck,
  CheckCircle2,
  Clock,
  MapPin,
  Phone,
  ShieldCheck,
  ArrowLeft,
  ChevronRight,
} from 'lucide-react';
import { Order, OrderStatus } from '../../types';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';

interface OrderTrackingViewProps {
  orderId?: string | null;
  onBackToOrders: () => void;
}

export const OrderTrackingView: React.FC<OrderTrackingViewProps> = ({
  orderId,
  onBackToOrders,
}) => {
  const { orders, updateOrderStatus } = useMarketplace();
  const [searchInput, setSearchInput] = useState(orderId || '');

  // Find targeted order
  const currentOrder: Order | undefined =
    orders.find((o) => o.id === orderId || o.orderNumber === orderId) ||
    orders.find((o) => o.id === searchInput || o.orderNumber === searchInput) ||
    orders[0];

  const trackingStages: { status: OrderStatus; label: string; labelBn: string; desc: string }[] = [
    { status: 'placed', label: 'Order Placed', labelBn: 'অর্ডার গ্রহণ', desc: 'Received & logged in LogeAchi system' },
    { status: 'confirmed', label: 'Confirmed', labelBn: 'নিশ্চিতকরণ', desc: 'Accepted by merchant shop' },
    { status: 'processing', label: 'Processing', labelBn: 'প্রক্রিয়াকরণ', desc: 'Packaged & quality inspected at hub' },
    { status: 'shipped', label: 'Shipped', labelBn: 'শিপিং', desc: 'Handed over to courier express rider' },
    { status: 'out_for_delivery', label: 'Out for Delivery', labelBn: 'ডেলিভারিতে', desc: 'Rider is arriving at your address' },
    { status: 'delivered', label: 'Delivered', labelBn: 'ডেলিভার্ড', desc: 'Successfully handed over to customer' },
  ];

  const getStageIndex = (st: OrderStatus) => {
    return trackingStages.findIndex((s) => s.status === st);
  };

  const currentIdx = currentOrder ? getStageIndex(currentOrder.orderStatus) : 0;

  // Simulator handler to advance status for live demo
  const handleAdvanceStatus = () => {
    if (!currentOrder) return;
    const nextIdx = Math.min(trackingStages.length - 1, currentIdx + 1);
    const nextStatus = trackingStages[nextIdx].status;
    updateOrderStatus(currentOrder.id, nextStatus, `Advanced by simulation to ${nextStatus}.`);
  };

  if (!currentOrder) {
    return (
      <div className="max-w-3xl mx-auto py-12 px-4 text-center">
        <h2 className="text-lg font-bold text-slate-800">No Order Found</h2>
        <button
          onClick={onBackToOrders}
          className="mt-4 px-4 py-2 bg-[#046A38] text-white rounded-xl text-xs font-bold"
        >
          View All Orders
        </button>
      </div>
    );
  }

  return (
    <div id="order-tracking-view" className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      {/* Back Button */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBackToOrders}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-[#046A38] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Orders</span>
        </button>

        {/* Demo Simulator button */}
        {currentOrder.orderStatus !== 'delivered' && (
          <button
            id="btn-simulate-next-status"
            onClick={handleAdvanceStatus}
            className="px-3 py-1.5 bg-[#FF6B00] hover:bg-[#E05E00] text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1"
          >
            <span>Advance Status (Live Demo Test)</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Main Tracking Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
              Live Order Tracker
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
              <span>{currentOrder.orderNumber}</span>
              <span className="text-xs font-bold text-[#046A38] bg-emerald-50 px-2.5 py-0.5 rounded-full capitalize">
                {currentOrder.orderStatus.replace('_', ' ')}
              </span>
            </h1>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500 block">Total Payable</span>
            <Currency amount={currentOrder.grandTotal} className="text-xl font-black text-[#046A38]" />
            <span className="text-[10px] text-slate-400 block mt-0.5 uppercase">
              {currentOrder.paymentMethod} • {currentOrder.paymentStatus}
            </span>
          </div>
        </div>

        {/* Visual Multi-step Horizontal Timeline */}
        <div className="py-8">
          <div className="relative flex items-center justify-between">
            {/* Connecting Bar */}
            <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-slate-100 w-full z-0"></div>
            <div
              className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-[#046A38] transition-all duration-500 z-0"
              style={{
                width: `${(currentIdx / (trackingStages.length - 1)) * 100}%`,
              }}
            ></div>

            {/* Stage Steps */}
            {trackingStages.map((stage, idx) => {
              const isPast = idx < currentIdx;
              const isCurrent = idx === currentIdx;

              return (
                <div key={stage.status} className="relative z-10 flex flex-col items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                      isPast
                        ? 'bg-[#046A38] text-white'
                        : isCurrent
                        ? 'bg-[#FF6B00] text-white ring-4 ring-orange-100 shadow-md scale-110'
                        : 'bg-white border-2 border-slate-200 text-slate-400'
                    }`}
                  >
                    {isPast ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                  </div>
                  <span
                    className={`text-[11px] font-bold mt-2 text-center whitespace-nowrap hidden sm:block ${
                      isCurrent ? 'text-[#FF6B00]' : isPast ? 'text-[#046A38]' : 'text-slate-400'
                    }`}
                  >
                    {stage.label}
                  </span>
                  <span className="text-[9px] text-slate-400 bangla-text hidden md:block">
                    {stage.labelBn}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Detailed Timeline Events */}
        <div className="mt-4 p-5 rounded-2xl bg-slate-50 border border-slate-200/80">
          <h3 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-[#046A38]" />
            <span>Activity Log & History</span>
          </h3>

          <div className="space-y-4">
            {currentOrder.trackingEvents.map((evt, idx) => (
              <div key={idx} className="flex items-start gap-3 text-xs">
                <div className="w-2.5 h-2.5 rounded-full bg-[#046A38] mt-1 shrink-0"></div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800">{evt.title}</span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(evt.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-slate-600 mt-0.5">{evt.description}</p>
                  {evt.location && (
                    <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {evt.location}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Details & Items summary */}
        <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider mb-2">
              Delivery Address:
            </h4>
            <div className="p-3 bg-white border border-slate-200 rounded-xl text-xs space-y-1">
              <p className="font-bold text-slate-800">{currentOrder.shippingAddress.fullName}</p>
              <p className="text-slate-600">{currentOrder.shippingAddress.phone}</p>
              <p className="text-slate-600">{currentOrder.shippingAddress.address}</p>
              <p className="text-slate-600">
                {currentOrder.shippingAddress.city}, {currentOrder.shippingAddress.district} (
                {currentOrder.shippingAddress.area === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})
              </p>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider mb-2">
              Ordered Items:
            </h4>
            <div className="space-y-2">
              {currentOrder.items.map((item, idx) => (
                <div
                  key={idx}
                  className="p-2.5 bg-white border border-slate-200 rounded-xl flex items-center gap-3 text-xs"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-10 h-10 rounded-lg object-cover bg-slate-100"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-slate-800 truncate">{item.name}</p>
                    <p className="text-slate-400 text-[10px]">
                      Qty: {item.quantity} {item.selectedSize ? `• Size: ${item.selectedSize}` : ''}
                    </p>
                  </div>
                  <Currency amount={item.price * item.quantity} className="font-bold text-slate-800" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

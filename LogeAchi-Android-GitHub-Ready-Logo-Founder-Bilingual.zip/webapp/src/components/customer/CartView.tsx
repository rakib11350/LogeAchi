import React, { useState } from 'react';
import {
  Trash2,
  ArrowRight,
  ShoppingBag,
  Tag,
  MapPin,
  ShieldCheck,
  Check,
  X,
} from 'lucide-react';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';

interface CartViewProps {
  onProceedToCheckout: () => void;
  onContinueShopping: () => void;
}

export const CartView: React.FC<CartViewProps> = ({
  onProceedToCheckout,
  onContinueShopping,
}) => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    cartSubtotal,
    deliveryCharge,
    shippingArea,
    setShippingArea,
    appliedCoupon,
    applyCouponCode,
    removeCoupon,
    discountAmount,
    cartGrandTotal,
    clearCart,
  } = useMarketplace();

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [applyingCoupon, setApplyingCoupon] = useState(false);

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setCouponError(null);
    setApplyingCoupon(true);

    const result = await applyCouponCode(couponInput.trim());
    setApplyingCoupon(false);
    if (!result.success) {
      setCouponError(result.message);
    } else {
      setCouponInput('');
    }
  };

  if (cart.length === 0) {
    return (
      <div id="empty-cart-view" className="max-w-xl mx-auto py-16 px-4 text-center">
        <div className="w-20 h-20 mx-auto rounded-full bg-[#E8F5E9] text-[#046A38] flex items-center justify-center mb-4">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">Your Cart is Empty</h2>
        <p className="text-sm text-slate-500 mt-1 mb-6">
          Looks like you haven't added any products to your cart yet.
        </p>
        <button
          id="btn-cart-continue-shopping"
          onClick={onContinueShopping}
          className="px-6 py-3 bg-[#046A38] hover:bg-[#024724] text-white font-bold rounded-xl shadow-md transition-colors text-sm"
        >
          Start Shopping Now
        </button>
      </div>
    );
  }

  return (
    <div id="customer-cart-view" className="max-w-6xl mx-auto py-8 px-4 sm:px-6">
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-black text-slate-900 flex items-center gap-2">
            <span>Shopping Cart</span>
            <span className="text-sm font-semibold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
              {cart.length} {cart.length === 1 ? 'item' : 'items'}
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5 bangla-text">
            আপনার পছন্দের পণ্যগুলো চেকআউট করুন সহজে।
          </p>
        </div>

        <button
          onClick={clearCart}
          className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear Cart</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left 8 columns: Items List */}
        <div className="lg:col-span-8 space-y-4">
          {cart.map((item, idx) => {
            const itemSubtotal = item.product.salePrice * item.quantity;
            return (
              <div
                key={`${item.productId}-${idx}`}
                className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-2xs hover:shadow-sm transition-shadow flex flex-col sm:flex-row items-start sm:items-center gap-4"
              >
                {/* Thumbnail */}
                <div className="w-20 h-20 rounded-xl bg-slate-100 overflow-hidden shrink-0 border border-slate-100">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#046A38] bg-emerald-50 px-2 py-0.5 rounded">
                    {item.product.shopName}
                  </span>
                  <h3 className="font-bold text-sm text-slate-800 truncate mt-1">
                    {item.product.name}
                  </h3>

                  {/* Variation tags */}
                  <div className="flex flex-wrap gap-2 mt-1 text-xs text-slate-500">
                    {item.selectedSize && (
                      <span className="bg-slate-100 px-2 py-0.5 rounded">
                        Size: <strong>{item.selectedSize}</strong>
                      </span>
                    )}
                    {item.selectedColor && (
                      <span className="bg-slate-100 px-2 py-0.5 rounded">
                        Color: <strong>{item.selectedColor}</strong>
                      </span>
                    )}
                    {item.selectedWeight && (
                      <span className="bg-slate-100 px-2 py-0.5 rounded">
                        Weight: <strong>{item.selectedWeight}</strong>
                      </span>
                    )}
                  </div>

                  <div className="mt-2 text-xs font-semibold text-slate-600">
                    Unit Price: <Currency amount={item.product.salePrice} />
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex sm:flex-col items-center justify-between w-full sm:w-auto gap-3">
                  <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50 overflow-hidden">
                    <button
                      onClick={() =>
                        updateCartQuantity(item.productId, item.quantity - 1, {
                          size: item.selectedSize,
                          color: item.selectedColor,
                        })
                      }
                      className="px-2.5 py-1 text-slate-600 hover:bg-slate-200 font-bold text-sm"
                    >
                      -
                    </button>
                    <span className="px-3 py-1 font-bold text-sm text-slate-800 min-w-[28px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() =>
                        updateCartQuantity(item.productId, item.quantity + 1, {
                          size: item.selectedSize,
                          color: item.selectedColor,
                        })
                      }
                      className="px-2.5 py-1 text-slate-600 hover:bg-slate-200 font-bold text-sm"
                    >
                      +
                    </button>
                  </div>

                  <div className="text-right flex items-center sm:flex-col gap-3 sm:gap-1">
                    <Currency amount={itemSubtotal} className="text-base font-bold text-slate-900" />
                    <button
                      onClick={() =>
                        removeFromCart(item.productId, {
                          size: item.selectedSize,
                          color: item.selectedColor,
                        })
                      }
                      className="text-xs text-rose-500 hover:text-rose-700 flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Remove</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          <div className="pt-2">
            <button
              onClick={onContinueShopping}
              className="text-xs font-bold text-[#046A38] hover:underline"
            >
              ← Continue Shopping for More Products
            </button>
          </div>
        </div>

        {/* Right 4 columns: Summary & Calculation */}
        <div className="lg:col-span-4 space-y-4">
          {/* Delivery Location Selector */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-2xs">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5 mb-2.5">
              <MapPin className="w-4 h-4 text-[#FF6B00]" />
              <span>Select Delivery Area</span>
            </h4>

            <div className="grid grid-cols-2 gap-2">
              <button
                id="btn-area-inside-dhaka"
                onClick={() => setShippingArea('inside_dhaka')}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  shippingArea === 'inside_dhaka'
                    ? 'border-[#046A38] bg-emerald-50/50 text-[#046A38] font-bold ring-1 ring-[#046A38]'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="text-xs font-bold">Inside Dhaka</div>
                <div className="text-[11px] text-slate-500 mt-0.5">৳80 (24-48 hrs)</div>
              </button>

              <button
                id="btn-area-outside-dhaka"
                onClick={() => setShippingArea('outside_dhaka')}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  shippingArea === 'outside_dhaka'
                    ? 'border-[#046A38] bg-emerald-50/50 text-[#046A38] font-bold ring-1 ring-[#046A38]'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="text-xs font-bold">Outside Dhaka</div>
                <div className="text-[11px] text-slate-500 mt-0.5">৳130 (2-4 days)</div>
              </button>
            </div>
          </div>

          {/* Coupon Code Applier */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-2xs">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5 mb-2">
              <Tag className="w-4 h-4 text-[#046A38]" />
              <span>Have a Coupon or Promo Code?</span>
            </h4>

            {appliedCoupon ? (
              <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <div>
                    <span className="font-bold text-[#046A38]">{appliedCoupon.code}</span>
                    <span className="text-emerald-700 ml-1.5">
                      ({appliedCoupon.discountType === 'percentage' ? `${appliedCoupon.discountValue}%` : `৳${appliedCoupon.discountValue}`} OFF)
                    </span>
                  </div>
                </div>
                <button
                  onClick={removeCoupon}
                  className="w-5 h-5 rounded-full hover:bg-emerald-200 text-emerald-800 flex items-center justify-center"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="space-y-1.5">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder="e.g. LOGEACHI50 or WELCOME100"
                    className="flex-1 text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-[#046A38] uppercase"
                  />
                  <button
                    type="submit"
                    disabled={applyingCoupon}
                    className="px-4 py-2 bg-[#046A38] hover:bg-[#024724] text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    {applyingCoupon ? '...' : 'Apply'}
                  </button>
                </div>
                {couponError && <p className="text-[11px] text-rose-500">{couponError}</p>}
                <div className="text-[10px] text-slate-400">
                  Try coupon: <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-600">LOGEACHI50</code> (৳500 off) or <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-600">WELCOME100</code>
                </div>
              </form>
            )}
          </div>

          {/* Order Financial Calculation Breakdown (Mandatory per section 12 & 14) */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-3">
            <h3 className="font-bold text-sm text-slate-800 pb-2 border-b border-slate-100">
              Order Summary
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Product Subtotal</span>
                <Currency amount={cartSubtotal} className="font-semibold text-slate-800" />
              </div>

              <div className="flex justify-between text-slate-600">
                <span>
                  Delivery Charge ({shippingArea === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})
                </span>
                <Currency amount={deliveryCharge} className="font-semibold text-slate-800" />
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-[#FF6B00] font-semibold">
                  <span>Discount ({appliedCoupon?.code})</span>
                  <span>-<Currency amount={discountAmount} /></span>
                </div>
              )}

              <div className="pt-3 border-t border-slate-200 flex justify-between items-baseline">
                <div>
                  <span className="text-base font-extrabold text-slate-900 block">Grand Total</span>
                  <span className="text-[11px] text-slate-400">সর্বমোট প্রদেয় মূল্য</span>
                </div>
                <Currency
                  amount={cartGrandTotal}
                  className="text-2xl font-black text-[#046A38]"
                />
              </div>
            </div>

            <button
              id="btn-proceed-to-checkout"
              onClick={onProceedToCheckout}
              className="w-full mt-4 py-3.5 px-4 bg-[#FF6B00] hover:bg-[#E05E00] text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 pt-2 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-[#046A38]" />
              <span>Safe & Verified Rocket / COD Checkout</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  ShieldAlert,
  Users,
  Store,
  ShoppingBag,
  TrendingUp,
  Tag,
  CheckCircle,
  XCircle,
  Clock,
  ShieldCheck,
  Percent,
  Plus,
  Search,
} from 'lucide-react';
import { Currency } from '../common/Currency';
import { useMarketplace } from '../../context/MarketplaceContext';
import { OrderStatus } from '../../types';

export const AdminPanel: React.FC = () => {
  const {
    products,
    orders,
    shops,
    coupons,
    teams,
    updateOrderStatus,
    createCoupon,
    showToast,
  } = useMarketplace();

  const [activeTab, setActiveTab] = useState<'analytics' | 'sellers' | 'orders' | 'coupons' | 'teams'>(
    'analytics'
  );

  // New Coupon form state
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponType, setNewCouponType] = useState<'percentage' | 'fixed'>('fixed');
  const [newCouponValue, setNewCouponValue] = useState<number>(100);
  const [newMinOrder, setNewMinOrder] = useState<number>(1000);

  const totalGMV = orders.reduce((sum, o) => sum + o.grandTotal, 0);
  const totalOrders = orders.length;
  const deliveredOrders = orders.filter((o) => o.orderStatus === 'delivered').length;

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;

    createCoupon({
      code: newCouponCode.trim().toUpperCase(),
      discountType: newCouponType,
      discountValue: Number(newCouponValue),
      minOrderAmount: Number(newMinOrder),
      validUntil: '2026-12-31',
      usageLimit: 500,
      timesUsed: 0,
      isActive: true,
    });

    setNewCouponCode('');
    showToast(`Coupon ${newCouponCode.toUpperCase()} created!`);
  };

  return (
    <div id="admin-panel-dashboard" className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      {/* Super Admin Top Banner with Founder Title */}
      <div className="bg-gradient-to-r from-slate-900 via-[#024724] to-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-wrap items-center justify-between gap-4 border border-emerald-900/60">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#046A38] text-white flex items-center justify-center font-black border border-emerald-400/40 shadow-inner">
            <ShieldAlert className="w-8 h-8 text-[#FF8C00]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black">Super Admin Command Hub</h1>
              <span className="bg-[#FF6B00] text-white text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                Full Control
              </span>
            </div>
            <p className="text-xs text-emerald-200 bangla-text mt-0.5">
              প্রতিষ্ঠাতা ও স্বত্বাধিকারী: <strong>মোঃ রাকিব হাসান (Founder & Owner — LogeAchi.com)</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs bg-emerald-950/80 px-3 py-1.5 rounded-xl border border-emerald-800 text-emerald-300 font-mono">
            Platform Status: 100% Operational
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-bold">
        {[
          { id: 'analytics', label: 'Platform Analytics', icon: TrendingUp },
          { id: 'sellers', label: `Verified Shops & Sellers (${shops.length})`, icon: Store },
          { id: 'orders', label: `Order Dispatch Operations (${orders.length})`, icon: ShoppingBag },
          { id: 'coupons', label: `Coupons & Discounts (${coupons.length})`, icon: Tag },
          { id: 'teams', label: `Reseller Teams (${teams.length})`, icon: Users },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
                isActive ? 'bg-[#046A38] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Analytics Tab */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Total Gross GMV</span>
              <Currency amount={totalGMV} className="text-2xl font-black text-[#046A38] mt-1" />
              <span className="text-[10px] text-emerald-600 font-bold block mt-1">+24.5% this month</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Platform Commission (5%)</span>
              <Currency amount={totalGMV * 0.05} className="text-2xl font-black text-[#FF6B00] mt-1" />
              <span className="text-[10px] text-slate-400 block mt-1">LogeAchi net commission</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Total Orders</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">{totalOrders}</span>
              <span className="text-[10px] text-emerald-600 font-bold block mt-1">{deliveredOrders} delivered</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-bold text-slate-400 block uppercase">Active Products</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">{products.length}</span>
              <span className="text-[10px] text-slate-400 block mt-1">Across all categories</span>
            </div>
          </div>

          {/* Delivery & Payment Matrix Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
              <h3 className="font-bold text-sm text-slate-900 mb-3">Payment Distribution</h3>
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-2.5 bg-purple-50 rounded-xl">
                  <span className="font-bold text-[#8B1874]">DBBL Rocket Mobile Banking</span>
                  <span className="font-mono font-bold text-purple-900">48% of volume</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-emerald-50 rounded-xl">
                  <span className="font-bold text-[#046A38]">Cash on Delivery (COD)</span>
                  <span className="font-mono font-bold text-emerald-900">36% of volume</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-pink-50 rounded-xl">
                  <span className="font-bold text-[#E2136E]">bKash & Nagad</span>
                  <span className="font-mono font-bold text-pink-900">16% of volume</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
              <h3 className="font-bold text-sm text-slate-900 mb-3">Delivery Zones Ratio</h3>
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="font-bold text-slate-800">Inside Dhaka (৳80 fee)</span>
                  <span className="font-mono font-bold text-slate-900">62% of shipments</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl">
                  <span className="font-bold text-slate-800">Outside Dhaka (৳130 fee - 63 Districts)</span>
                  <span className="font-mono font-bold text-slate-900">38% of shipments</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Sellers Tab */}
      {activeTab === 'sellers' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-base text-slate-900">Registered Marketplace Sellers</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {shops.map((shop) => (
              <div key={shop.id} className="p-4 border border-slate-200 rounded-2xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <img src={shop.logo} alt="" className="w-12 h-12 rounded-xl object-cover" />
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{shop.name}</h4>
                      <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                        Trade License: TL-89214
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-2">{shop.description}</p>
                </div>

                <div className="pt-3 mt-3 border-t flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Status: Active</span>
                  <span className="bg-emerald-100 text-[#046A38] text-[10px] font-bold px-2 py-0.5 rounded-full">
                    Verified Seller
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Orders Tab */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-base text-slate-900">Central Order Management & Dispatch</h3>
          <div className="space-y-3">
            {orders.map((o) => (
              <div key={o.id} className="p-4 border rounded-2xl flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-[#046A38]">{o.orderNumber}</span>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase bg-slate-100">
                      {o.orderStatus}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Customer: <strong>{o.customerName}</strong> ({o.customerPhone})
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Destination: {o.shippingAddress.address}, {o.shippingAddress.city} (
                    {o.shippingAddress.area === 'inside_dhaka' ? 'Inside Dhaka ৳80' : 'Outside Dhaka ৳130'})
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <Currency amount={o.grandTotal} className="text-base font-black text-slate-900" />
                    <span className="text-[10px] text-slate-400 block uppercase">{o.paymentMethod}</span>
                  </div>

                  <select
                    value={o.orderStatus}
                    onChange={(e) => updateOrderStatus(o.id, e.target.value as OrderStatus)}
                    className="text-xs font-bold p-2 rounded-xl border bg-white focus:outline-[#046A38]"
                  >
                    <option value="placed">Placed</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="out_for_delivery">Out for Delivery</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Coupons Tab */}
      {activeTab === 'coupons' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Coupon Form */}
          <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
            <h3 className="font-bold text-sm text-slate-900 mb-3">Create Promotional Coupon</h3>
            <form onSubmit={handleCreateCoupon} className="space-y-3 text-xs">
              <div>
                <label className="font-bold block mb-1">Coupon Code (e.g. EID2026)</label>
                <input
                  type="text"
                  required
                  value={newCouponCode}
                  onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                  placeholder="CODE"
                  className="w-full p-2.5 rounded-xl border uppercase"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold block mb-1">Discount Type</label>
                  <select
                    value={newCouponType}
                    onChange={(e) => setNewCouponType(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border bg-white"
                  >
                    <option value="fixed">Fixed ৳ BDT</option>
                    <option value="percentage">Percentage %</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold block mb-1">Value</label>
                  <input
                    type="number"
                    value={newCouponValue}
                    onChange={(e) => setNewCouponValue(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl border"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold block mb-1">Minimum Order Amount (৳)</label>
                <input
                  type="number"
                  value={newMinOrder}
                  onChange={(e) => setNewMinOrder(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#046A38] text-white font-bold rounded-xl text-xs"
              >
                Create Coupon
              </button>
            </form>
          </div>

          {/* Coupon List */}
          <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
            <h3 className="font-bold text-sm text-slate-900 mb-3">Active Promotional Codes</h3>
            <div className="space-y-2.5">
              {coupons.map((c) => (
                <div key={c.id} className="p-3.5 bg-slate-50 rounded-2xl flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-black text-sm text-[#046A38]">{c.code}</span>
                    <span className="text-slate-500 ml-2">
                      ({c.discountType === 'percentage' ? `${c.discountValue}%` : `৳${c.discountValue}`} OFF)
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      Min Order: ৳{c.minOrderAmount} • Used {c.timesUsed} times
                    </span>
                  </div>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                    Active
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. Teams Tab */}
      {activeTab === 'teams' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-base text-slate-900">Reseller Team Networks</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {teams.map((t) => (
              <div key={t.id} className="p-4 border rounded-2xl">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-sm text-slate-900">{t.name}</h4>
                  <span className="text-xs font-mono font-bold bg-purple-50 text-purple-700 px-2 py-0.5 rounded">
                    {t.inviteCode}
                  </span>
                </div>
                <p className="text-xs text-slate-500">Leader: {t.leaderName}</p>
                <div className="mt-3 pt-2 border-t flex justify-between text-xs">
                  <span>Members: {t.membersCount}</span>
                  <span className="font-bold text-[#046A38]">Sales: <Currency amount={t.totalSales} /></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

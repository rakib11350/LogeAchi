import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  showSlogan?: boolean;
  variant?: 'full' | 'compact' | 'symbol';
  className?: string;
  onClick?: () => void;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  showTagline = true,
  showSlogan = false,
  variant = 'full',
  className = '',
  onClick,
}) => {
  const widths = { sm: 150, md: 190, lg: 240, xl: 300 } as const;

  if (variant === 'full' || variant === 'compact') {
    return (
      <div
        id="loge-achi-brand-logo"
        onClick={onClick}
        className={`inline-flex flex-col items-center select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
      >
        <img
          src="/logeachi-logo.png"
          alt="LOGEACHI.COM — লগে আছি ডটকম"
          style={{ width: widths[size], height: 'auto' }}
          className="block object-contain"
          draggable={false}
        />
        {showSlogan && (
          <p className="text-xs text-gray-500 bangla-text mt-1 text-center font-medium">
            “আপনার স্বপ্ন, আমাদের সাথে—লগে আছি।”
          </p>
        )}
      </div>
    );
  }

  return (
    <div
      id="loge-achi-brand-logo"
      onClick={onClick}
      className={`inline-flex items-center justify-center select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      <img
        src="/logeachi-icon.png"
        alt="LogeAchi.com"
        style={{ width: size === 'sm' ? 36 : size === 'md' ? 44 : size === 'lg' ? 64 : 84, height: 'auto' }}
        className="block object-contain"
        draggable={false}
      />
    </div>
  );
};

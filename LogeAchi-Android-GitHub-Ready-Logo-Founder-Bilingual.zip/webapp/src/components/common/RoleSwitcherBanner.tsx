import React from 'react';
import {
  Smartphone,
  Store,
  Share2,
  ShieldAlert,
  UserCog,
  Monitor,
  Database,
  Globe,
} from 'lucide-react';
import { useMarketplace } from '../../context/MarketplaceContext';

export const RoleSwitcherBanner: React.FC = () => {
  const {
    activePortal,
    setActivePortal,
    currentUser,
    loginAsRole,
    mobilePreviewMode,
    setMobilePreviewMode,
    language,
    setLanguage,
  } = useMarketplace();

  const portals = [
    { id: 'customer', name: 'Customer App', icon: Smartphone, role: 'customer' as const },
    { id: 'seller', name: 'Seller Panel', icon: Store, role: 'seller' as const },
    { id: 'reseller', name: 'Reseller Hub', icon: Share2, role: 'reseller' as const },
    { id: 'super_admin', name: 'Super Admin', icon: ShieldAlert, role: 'super_admin' as const },
    { id: 'staff', name: 'Staff Panel', icon: UserCog, role: 'staff' as const },
    { id: 'api_docs', name: 'API & Architecture', icon: Database, role: null },
  ];

  return (
    <header
      id="loge-achi-control-bar"
      className="bg-[#024724] text-white border-b border-[#046A38] text-xs py-2 px-3 sm:px-6 sticky top-0 z-40 shadow-xs"
    >
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2.5">
        {/* Left: Brand Identity & Founder Notice */}
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 font-bold tracking-wide text-[#FF8C00]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            LogeAchi.com
          </span>
          <span className="text-emerald-300/40">|</span>
          <span className="bangla-text text-emerald-100 hidden md:inline">
            প্রতিষ্ঠাতা: মোঃ রাকিব হাসান (Founder & Owner)
          </span>
        </div>

        {/* Center: Major Panels Navigation */}
        <nav aria-label="Portal selection" className="flex items-center gap-1 overflow-x-auto py-0.5 scrollbar-none">
          {portals.map((p) => {
            const Icon = p.icon;
            const isActive = activePortal === p.id;
            return (
              <button
                key={p.id}
                id={`btn-portal-${p.id}`}
                onClick={() => {
                  setActivePortal(p.id as any);
                  if (p.role) {
                    loginAsRole(p.role);
                  }
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-[#FF6B00] text-white shadow-xs font-semibold'
                    : 'text-emerald-100 hover:bg-[#046A38] hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{p.name}</span>
              </button>
            );
          })}
        </nav>

        {/* Right: Controls (Mobile Preview Switch & Language) */}
        <div className="flex items-center gap-2">
          {/* Mobile Simulator Toggle (active when in customer mode) */}
          {activePortal === 'customer' && (
            <button
              id="btn-toggle-mobile-mode"
              onClick={() => setMobilePreviewMode(!mobilePreviewMode)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-colors ${
                mobilePreviewMode
                  ? 'bg-white text-[#046A38] font-bold shadow-xs'
                  : 'bg-[#046A38] text-emerald-100 hover:text-white'
              }`}
              title="Toggle Flutter Mobile App preview mode"
            >
              {mobilePreviewMode ? (
                <>
                  <Monitor className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Web View</span>
                </>
              ) : (
                <>
                  <Smartphone className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Mobile App View</span>
                </>
              )}
            </button>
          )}

          {/* Language Toggle */}
          <button
            id="btn-toggle-language"
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            className="flex items-center gap-1 px-2 py-1 bg-[#046A38] hover:bg-[#068a49] text-emerald-100 rounded-md font-medium"
          >
            <Globe className="w-3.5 h-3.5 text-[#FF8C00]" />
            <span>{language === 'en' ? 'বাংলা' : 'EN'}</span>
          </button>

          {/* Active User Pill */}
          <div className="hidden lg:flex items-center gap-1.5 pl-1.5 border-l border-[#046A38]">
            <img
              src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50&auto=format&fit=crop&q=80'}
              alt={currentUser.name}
              className="w-5 h-5 rounded-full object-cover border border-emerald-400"
            />
            <span className="text-emerald-100 font-medium max-w-[120px] truncate">
              {currentUser.name.split(' ')[0]}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};

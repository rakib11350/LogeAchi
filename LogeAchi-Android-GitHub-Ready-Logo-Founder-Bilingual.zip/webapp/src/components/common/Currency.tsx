import React from 'react';

interface CurrencyProps {
  amount: number;
  className?: string;
  showSign?: boolean;
}

export const formatBDT = (amount: number): string => {
  return new Intl.NumberFormat('en-IN').format(Math.round(amount));
};

export const Currency: React.FC<CurrencyProps> = ({ amount, className = '', showSign = true }) => {
  return (
    <span className={`inline-flex items-center font-semibold tracking-tight ${className}`}>
      {showSign && <span className="font-normal mr-0.5">৳</span>}
      {formatBDT(amount)}
    </span>
  );
};

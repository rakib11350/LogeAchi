import React from 'react';
import { Star } from 'lucide-react';

interface RatingStarsProps {
  rating: number;
  maxStars?: number;
  size?: 'sm' | 'md' | 'lg';
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
  showCount?: boolean;
  count?: number;
}

export const RatingStars: React.FC<RatingStarsProps> = ({
  rating,
  maxStars = 5,
  size = 'sm',
  interactive = false,
  onRatingChange,
  showCount = false,
  count,
}) => {
  const sizeMap = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
    lg: 'w-5 h-5',
  };

  return (
    <div className="inline-flex items-center gap-1">
      <div className="flex items-center">
        {Array.from({ length: maxStars }).map((_, idx) => {
          const starValue = idx + 1;
          const isFilled = starValue <= Math.round(rating);
          return (
            <Star
              key={idx}
              className={`${sizeMap[size]} ${
                isFilled ? 'text-amber-400 fill-amber-400' : 'text-gray-300'
              } ${interactive ? 'cursor-pointer transition-transform hover:scale-115' : ''}`}
              onClick={() => interactive && onRatingChange && onRatingChange(starValue)}
            />
          );
        })}
      </div>
      {showCount && (
        <span className="text-xs text-gray-500 font-medium ml-1">
          {rating.toFixed(1)} {count !== undefined ? `(${count})` : ''}
        </span>
      )}
    </div>
  );
};

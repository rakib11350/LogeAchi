import React from 'react';
import { Award, ShieldCheck } from 'lucide-react';

interface FounderBadgeProps {
  compact?: boolean;
}

export const FounderBadge: React.FC<FounderBadgeProps> = ({ compact = false }) => {
  if (compact) {
    return (
      <div
        id="founder-badge-compact"
        className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-[#046A38]/10 to-[#FF6B00]/10 border border-[#046A38]/20 rounded-full text-xs text-gray-700"
      >
        <ShieldCheck className="w-3.5 h-3.5 text-[#046A38]" />
        <span className="font-medium bangla-text">প্রতিষ্ঠাতা: মোঃ রাকিব হাসান</span>
      </div>
    );
  }

  return (
    <div
      id="founder-badge-card"
      className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-7 shadow-sm overflow-hidden"
    >
      <div className="grid grid-cols-1 md:grid-cols-[180px_1fr] gap-6 items-center">
        <div className="flex justify-center md:justify-start">
          <div className="w-40 h-40 sm:w-44 sm:h-44 rounded-3xl overflow-hidden border-4 border-[#FF6B00]/20 shadow-md bg-slate-100">
            <img
              src="/founder-rakib-hasan.png"
              alt="মোঃ রাকিব হাসান — Owner & CEO, LogeAchi.com"
              className="w-full h-full object-cover"
              draggable={false}
            />
          </div>
        </div>

        <div>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="text-xs font-black uppercase tracking-wider text-[#046A38] bg-[#E8F5E9] px-3 py-1 rounded-full">
              About the Founder
            </span>
            <Award className="w-5 h-5 text-[#FF6B00]" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900">মোঃ রাকিব হাসান</h2>
          <p className="text-sm sm:text-base font-bold text-[#046A38] mt-1">
            Owner &amp; CEO — LogeAchi.com
          </p>
          <p className="text-sm font-semibold text-slate-600 bangla-text mt-0.5">
            মালিক ও প্রধান নির্বাহী কর্মকর্তা — লগে আছি ডটকম
          </p>

          <div className="mt-5 space-y-3 text-sm text-slate-600 leading-relaxed">
            <div>
              <h3 className="font-black text-slate-900 bangla-text mb-1">আমার পরিচয় ও সফলতার গল্প</h3>
              <p className="bangla-text">
                স্বপ্নকে বাস্তবে রূপ দেওয়ার পথ সবসময় সহজ ছিল না। পরিশ্রম, ধৈর্য, শেখার মানসিকতা এবং মানুষের জন্য কিছু করার ইচ্ছা থেকেই LogeAchi.com-এর পথচলা। প্রতিটি বাধা থেকে শিক্ষা নিয়ে ধীরে ধীরে এই স্বপ্নকে একটি অনলাইন মার্কেটপ্লেসে রূপ দেওয়ার চেষ্টা করছি।
              </p>
            </div>
            <div>
              <h3 className="font-black text-slate-900 mb-1">My Journey &amp; Vision</h3>
              <p>
                The journey has been built on hard work, patience and a clear vision. LogeAchi.com is my dream to make online shopping easier, safer and more convenient for customers and sellers.
              </p>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 text-xs text-slate-500">
            <span className="bangla-text">প্রতিষ্ঠাতা ও স্বত্বাধিকারী: </span>
            <strong className="text-slate-800">মোঃ রাকিব হাসান</strong>
            <span className="mx-1">•</span>
            <span>Owner &amp; CEO</span>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { ReactNode } from 'react';
import { Wifi, Battery, Signal, Home, Grid, ShoppingBag, Clock, User as UserIcon } from 'lucide-react';
import { useMarketplace } from '../../context/MarketplaceContext';

interface MobileFrameProps {
  children: ReactNode;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ children }) => {
  const { customerView, setCustomerView, cartCount, unreadNotificationsCount } = useMarketplace();

  const navItems = [
    { id: 'home', label: 'Home', labelBn: 'হোম', icon: Home },
    { id: 'categories', label: 'Categories', labelBn: 'ক্যাটাগরি', icon: Grid },
    { id: 'cart', label: 'Cart', labelBn: 'কার্ট', icon: ShoppingBag, badge: cartCount },
    { id: 'orders', label: 'Orders', labelBn: 'অর্ডার', icon: Clock },
    { id: 'profile', label: 'Profile', labelBn: 'প্রোফাইল', icon: UserIcon },
  ];

  return (
    <div className="py-6 px-4 flex justify-center items-start min-h-[calc(100vh-50px)] bg-slate-200/80">
      {/* Phone Shell */}
      <div
        id="mobile-phone-device-frame"
        className="w-full max-w-[420px] h-[860px] bg-slate-900 rounded-[48px] p-3 shadow-2xl border-4 border-slate-800 flex flex-col relative overflow-hidden"
      >
        {/* Dynamic Island / Notch */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full z-50 flex items-center justify-center">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700 mr-2"></div>
          <div className="w-1.5 h-1.5 rounded-full bg-slate-800"></div>
        </div>

        {/* Screen Inner Viewport */}
        <div className="w-full h-full bg-[#F8FAFC] rounded-[38px] flex flex-col overflow-hidden relative">
          {/* Status Bar */}
          <div className="h-10 pt-2 px-6 flex items-center justify-between text-[11px] font-semibold text-slate-800 z-40 shrink-0 bg-white/90 backdrop-blur-xs">
            <span>09:41</span>
            <div className="flex items-center gap-1.5 text-slate-700">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4" />
            </div>
          </div>

          {/* Main Scrollable Content */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden scrollbar-none pb-20">
            {children}
          </div>

          {/* Mobile Bottom Navigation Bar (Flutter-style) */}
          <div
            id="mobile-bottom-nav-bar"
            className="absolute bottom-0 left-0 right-0 h-16 bg-white/95 backdrop-blur-md border-t border-slate-200 flex items-center justify-around px-2 z-40"
          >
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = customerView === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  onClick={() => setCustomerView(item.id as any)}
                  className={`flex flex-col items-center justify-center flex-1 py-1 relative transition-colors ${
                    isActive ? 'text-[#046A38]' : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  <div className="relative">
                    <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
                    {item.badge && item.badge > 0 ? (
                      <span className="absolute -top-1 -right-2 bg-[#FF6B00] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                        {item.badge}
                      </span>
                    ) : null}
                  </div>
                  <span className={`text-[10px] mt-1 ${isActive ? 'font-bold' : 'font-medium'}`}>
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Home Bar Indicator */}
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-32 h-1 bg-slate-300 rounded-full z-50 pointer-events-none"></div>
        </div>
      </div>
    </div>
  );
};

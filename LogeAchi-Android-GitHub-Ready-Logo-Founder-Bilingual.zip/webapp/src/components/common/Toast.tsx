import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { useMarketplace } from '../../context/MarketplaceContext';

export const Toast: React.FC = () => {
  const { toastMessage } = useMarketplace();

  if (!toastMessage) return null;

  return (
    <div
      id="global-toast"
      className="fixed bottom-6 right-6 z-50 max-w-md bg-[#0F172A] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-slate-700 animate-in fade-in slide-in-from-bottom-5 duration-300"
    >
      <div className="w-7 h-7 rounded-full bg-[#046A38] text-white flex items-center justify-center shrink-0">
        <CheckCircle2 className="w-4 h-4" />
      </div>
      <p className="text-sm font-medium text-slate-100">{toastMessage}</p>
    </div>
  );
};

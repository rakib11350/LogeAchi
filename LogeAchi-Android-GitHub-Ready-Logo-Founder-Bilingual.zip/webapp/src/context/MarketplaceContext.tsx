import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  User,
  UserRole,
  Product,
  Category,
  Shop,
  Order,
  CartItem,
  Coupon,
  Notification,
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_SHOPS,
  INITIAL_USERS,
  INITIAL_ORDERS,
  INITIAL_COUPONS,
  INITIAL_NOTIFICATIONS,
} from '../data/initialData';

interface MarketplaceContextType {
  currentUser: User;
  setCurrentUser: (user: User) => void;
  activeRole: UserRole;
  language: 'en' | 'bn';
  setLanguage: (lang: 'en' | 'bn') => void;
  activePortal: 'customer' | 'seller' | 'reseller' | 'super_admin' | 'staff' | 'api_docs';
  setActivePortal: (portal: 'customer' | 'seller' | 'reseller' | 'super_admin' | 'staff' | 'api_docs') => void;
  customerView: 'home' | 'search' | 'categories' | 'cart' | 'checkout' | 'orders' | 'tracking' | 'profile' | 'support' | 'wishlist';
  setCustomerView: (view: 'home' | 'search' | 'categories' | 'cart' | 'checkout' | 'orders' | 'tracking' | 'profile' | 'support' | 'wishlist') => void;
  selectedCategorySlug: string | null;
  setSelectedCategorySlug: (slug: string | null) => void;
  selectedShopId: string | null;
  setSelectedShopId: (shopId: string | null) => void;
  selectedProductId: string | null;
  setSelectedProductId: (id: string | null) => void;
  trackingOrderId: string | null;
  setTrackingOrderId: (id: string | null) => void;
  mobilePreviewMode: boolean;
  setMobilePreviewMode: (val: boolean) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, options?: { size?: string; color?: string; weight?: string }) => void;
  updateCartQuantity: (productId: string, quantity: number, options?: { size?: string; color?: string }) => void;
  removeFromCart: (productId: string, options?: { size?: string; color?: string }) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  deliveryCharge: number;
  shippingArea: 'inside_dhaka' | 'outside_dhaka';
  setShippingArea: (area: 'inside_dhaka' | 'outside_dhaka') => void;
  appliedCoupon: Coupon | null;
  applyCouponCode: (code: string) => Promise<{ success: boolean; message: string }>;
  removeCoupon: () => void;
  discountAmount: number;
  cartGrandTotal: number;

  // Wishlist
  wishlist: Product[];
  toggleWishlist: (product: Product) => void;
  isInWishlist: (productId: string) => boolean;

  // Data
  products: Product[];
  categories: Category[];
  shops: Shop[];
  orders: Order[];
  coupons: Coupon[];
  notifications: Notification[];
  unreadNotificationsCount: number;
  markNotificationRead: (id: string) => void;

  // Actions
  loginAsRole: (role: UserRole) => void;
  refreshData: () => Promise<void>;
  createOrder: (payload: any) => Promise<Order>;
  updateOrderStatus: (orderId: string, status: any, note?: string) => Promise<void>;
  approveProduct: (productId: string, approved: boolean) => Promise<void>;
  approveSeller: (shopId: string, approved: boolean) => Promise<void>;
  addProduct: (productData: any) => Promise<Product>;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const MarketplaceContext = createContext<MarketplaceContextType | undefined>(undefined);

export const MarketplaceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[3]); // Default to Customer Sabrina
  const [language, setLanguage] = useState<'en' | 'bn'>('en');
  const [activePortal, setActivePortal] = useState<'customer' | 'seller' | 'reseller' | 'super_admin' | 'staff' | 'api_docs'>('customer');
  const [customerView, setCustomerView] = useState<'home' | 'search' | 'categories' | 'cart' | 'checkout' | 'orders' | 'tracking' | 'profile' | 'support' | 'wishlist'>('home');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string | null>(null);
  const [selectedShopId, setSelectedShopId] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [trackingOrderId, setTrackingOrderId] = useState<string | null>(null);
  const [mobilePreviewMode, setMobilePreviewMode] = useState<boolean>(false);

  // Core Data
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [shops, setShops] = useState<Shop[]>(INITIAL_SHOPS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [coupons, setCoupons] = useState<Coupon[]>(INITIAL_COUPONS);
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);

  // Cart & Wishlist
  const [cart, setCart] = useState<CartItem[]>([
    {
      productId: INITIAL_PRODUCTS[1].id,
      product: INITIAL_PRODUCTS[1],
      quantity: 1,
      selectedSize: '40',
      selectedColor: 'Pure White',
    },
  ]);
  const [wishlist, setWishlist] = useState<Product[]>([INITIAL_PRODUCTS[0]]);
  const [shippingArea, setShippingArea] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Fetch live from server on mount
  const refreshData = async () => {
    try {
      const [prodRes, catRes, shopRes, ordRes, notifRes] = await Promise.all([
        fetch('/api/products').then((r) => (r.ok ? r.json() : null)),
        fetch('/api/categories').then((r) => (r.ok ? r.json() : null)),
        fetch('/api/shops').then((r) => (r.ok ? r.json() : null)),
        fetch('/api/orders').then((r) => (r.ok ? r.json() : null)),
        fetch('/api/notifications').then((r) => (r.ok ? r.json() : null)),
      ]);

      if (prodRes) setProducts(prodRes);
      if (catRes) setCategories(catRes);
      if (shopRes) setShops(shopRes);
      if (ordRes) setOrders(ordRes);
      if (notifRes) setNotifications(notifRes);
    } catch {
      // Fallback on in-memory initial data
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  // Cart Calculations
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.salePrice * item.quantity, 0);
  const deliveryCharge = cart.length === 0 ? 0 : shippingArea === 'inside_dhaka' ? 80 : 130;

  let discountAmount = 0;
  if (appliedCoupon && cartSubtotal >= appliedCoupon.minOrderValue) {
    if (appliedCoupon.discountType === 'percentage') {
      discountAmount = Math.round((cartSubtotal * appliedCoupon.discountValue) / 100);
      if (appliedCoupon.maxDiscount && discountAmount > appliedCoupon.maxDiscount) {
        discountAmount = appliedCoupon.maxDiscount;
      }
    } else {
      discountAmount = appliedCoupon.discountValue;
    }
  }

  const cartGrandTotal = Math.max(0, cartSubtotal + deliveryCharge - discountAmount);

  const addToCart = (product: Product, quantity = 1, options?: { size?: string; color?: string; weight?: string }) => {
    setCart((prev) => {
      const existingIdx = prev.findIndex(
        (i) =>
          i.productId === product.id &&
          i.selectedSize === options?.size &&
          i.selectedColor === options?.color
      );

      if (existingIdx > -1) {
        const copy = [...prev];
        copy[existingIdx].quantity += quantity;
        return copy;
      }

      return [
        ...prev,
        {
          productId: product.id,
          product,
          quantity,
          selectedSize: options?.size,
          selectedColor: options?.color,
          selectedWeight: options?.weight,
        },
      ];
    });

    showToast(`Added "${product.name.slice(0, 24)}..." to cart!`);
  };

  const updateCartQuantity = (productId: string, quantity: number, options?: { size?: string; color?: string }) => {
    if (quantity <= 0) {
      removeFromCart(productId, options);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (
          item.productId === productId &&
          item.selectedSize === options?.size &&
          item.selectedColor === options?.color
        ) {
          return { ...item, quantity };
        }
        return item;
      })
    );
  };

  const removeFromCart = (productId: string, options?: { size?: string; color?: string }) => {
    setCart((prev) =>
      prev.filter(
        (item) =>
          !(
            item.productId === productId &&
            item.selectedSize === options?.size &&
            item.selectedColor === options?.color
          )
      )
    );
    showToast('Item removed from cart');
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  const applyCouponCode = async (code: string) => {
    try {
      const res = await fetch('/api/cart/apply-coupon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, subtotal: cartSubtotal }),
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        setAppliedCoupon(data.coupon);
        showToast(`Coupon "${data.coupon.code}" applied! Saved ৳${data.discount}`);
        return { success: true, message: data.message };
      } else {
        return { success: false, message: data.error || 'Invalid coupon code' };
      }
    } catch {
      // Offline fallback
      const found = coupons.find((c) => c.code.toUpperCase() === code.toUpperCase() && c.isActive);
      if (found) {
        if (cartSubtotal >= found.minOrderValue) {
          setAppliedCoupon(found);
          showToast(`Coupon "${found.code}" applied!`);
          return { success: true, message: 'Coupon applied successfully!' };
        }
        return { success: false, message: `Minimum order ৳${found.minOrderValue} required.` };
      }
      return { success: false, message: 'Invalid coupon code.' };
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    showToast('Coupon removed');
  };

  // Wishlist
  const toggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        showToast(`Removed from Wishlist`);
        return prev.filter((p) => p.id !== product.id);
      } else {
        showToast(`Added to Wishlist!`);
        return [...prev, product];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.some((p) => p.id === productId);

  // Role Switcher
  const loginAsRole = (role: UserRole) => {
    const matchedUser = INITIAL_USERS.find((u) => u.role === role) || INITIAL_USERS[0];
    setCurrentUser(matchedUser);

    if (role === 'super_admin') {
      setActivePortal('super_admin');
    } else if (role === 'seller') {
      setActivePortal('seller');
    } else if (role === 'reseller') {
      setActivePortal('reseller');
    } else if (role === 'staff') {
      setActivePortal('staff');
    } else {
      setActivePortal('customer');
    }

    showToast(`Switched account to: ${matchedUser.name} (${role.replace('_', ' ').toUpperCase()})`);
  };

  // Notifications
  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;
  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    fetch(`/api/notifications/${id}/read`, { method: 'PUT' }).catch(() => {});
  };

  // API Order actions
  const createOrder = async (payload: any): Promise<Order> => {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      throw new Error('Failed to create order');
    }
    const newOrder = await res.json();
    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    setTrackingOrderId(newOrder.id);
    showToast(`Order #${newOrder.orderNumber} placed successfully!`);
    return newOrder;
  };

  const updateOrderStatus = async (orderId: string, status: any, note?: string) => {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note }),
    });
    if (res.ok) {
      const updated = await res.json();
      setOrders((prev) => prev.map((o) => (o.id === orderId ? updated : o)));
      showToast(`Order status updated to: ${status.toUpperCase()}`);
    }
  };

  const approveProduct = async (productId: string, approved: boolean) => {
    const res = await fetch('/api/admin/approve-product', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, approved }),
    });
    if (res.ok) {
      setProducts((prev) =>
        prev.map((p) => (p.id === productId ? { ...p, status: approved ? 'approved' : 'rejected' } : p))
      );
      showToast(`Product ${approved ? 'Approved' : 'Rejected'}!`);
    }
  };

  const approveSeller = async (shopId: string, approved: boolean) => {
    const res = await fetch('/api/admin/approve-seller', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ shopId, approved }),
    });
    if (res.ok) {
      setShops((prev) =>
        prev.map((s) => (s.id === shopId ? { ...s, status: approved ? 'approved' : 'suspended', verified: approved } : s))
      );
      showToast(`Seller store ${approved ? 'Approved & Verified' : 'Suspended'}`);
    }
  };

  const addProduct = async (productData: any): Promise<Product> => {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(productData),
    });
    const newProd = await res.json();
    setProducts((prev) => [newProd, ...prev]);
    showToast('New product submitted successfully!');
    return newProd;
  };

  return (
    <MarketplaceContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        activeRole: currentUser.role,
        language,
        setLanguage,
        activePortal,
        setActivePortal,
        customerView,
        setCustomerView,
        selectedCategorySlug,
        setSelectedCategorySlug,
        selectedShopId,
        setSelectedShopId,
        selectedProductId,
        setSelectedProductId,
        trackingOrderId,
        setTrackingOrderId,
        mobilePreviewMode,
        setMobilePreviewMode,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartCount,
        cartSubtotal,
        deliveryCharge,
        shippingArea,
        setShippingArea,
        appliedCoupon,
        applyCouponCode,
        removeCoupon,
        discountAmount,
        cartGrandTotal,
        wishlist,
        toggleWishlist,
        isInWishlist,
        products,
        categories,
        shops,
        orders,
        coupons,
        notifications,
        unreadNotificationsCount,
        markNotificationRead,
        loginAsRole,
        refreshData,
        createOrder,
        updateOrderStatus,
        approveProduct,
        approveSeller,
        addProduct,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </MarketplaceContext.Provider>
  );
};

export const useMarketplace = () => {
  const context = useContext(MarketplaceContext);
  if (!context) {
    throw new Error('useMarketplace must be used within a MarketplaceProvider');
  }
  return context;
};

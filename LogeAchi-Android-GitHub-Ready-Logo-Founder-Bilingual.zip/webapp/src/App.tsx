import React, { useState } from 'react';
import { MarketplaceProvider, useMarketplace } from './context/MarketplaceContext';
import { RoleSwitcherBanner } from './components/common/RoleSwitcherBanner';
import { MobileFrame } from './components/common/MobileFrame';
import { Toast } from './components/common/Toast';
import { CustomerHeader } from './components/customer/CustomerHeader';
import { CustomerHome } from './components/customer/CustomerHome';
import { CategoryProductsView } from './components/customer/CategoryProductsView';
import { CartView } from './components/customer/CartView';
import { CheckoutModal } from './components/customer/CheckoutModal';
import { OrderConfirmationModal } from './components/customer/OrderConfirmationModal';
import { ProductDetailModal } from './components/customer/ProductDetailModal';
import { OrderTrackingView } from './components/customer/OrderTrackingView';
import { OrderHistoryView } from './components/customer/OrderHistoryView';
import { CustomerProfileView } from './components/customer/CustomerProfileView';
import { CustomerSupportView } from './components/customer/CustomerSupportView';
import { AuthModal } from './components/customer/AuthModal';
import { SellerPanel } from './components/seller/SellerPanel';
import { ResellerPanel } from './components/reseller/ResellerPanel';
import { AdminPanel } from './components/admin/AdminPanel';
import { ApiDocsView } from './components/docs/ApiDocsView';
import { BrandLogo } from './components/common/BrandLogo';
import { Product, Order } from './types';
import { ShieldCheck, Heart } from 'lucide-react';

const MarketplaceApp: React.FC = () => {
  const {
    activePortal,
    customerView,
    setCustomerView,
    mobilePreviewMode,
    setSelectedCategorySlug,
    wishlist,
    addToCart,
  } = useMarketplace();

  // Search keyword state
  const [searchKeyword, setSearchKeyword] = useState('');

  // Selected product for detail modal
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);

  // Active modals
  const [showCheckout, setShowCheckout] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [trackingOrderId, setTrackingOrderId] = useState<string | null>(null);

  const handleOpenDetail = (product: Product) => {
    setActiveProduct(product);
  };

  const handleBuyNow = (
    product: Product,
    options: { size?: string; color?: string; weight?: string; quantity: number }
  ) => {
    addToCart(product, options.quantity, {
      size: options.size,
      color: options.color,
      weight: options.weight,
    });
    setActiveProduct(null);
    setShowCheckout(true);
  };

  const handleSelectCategory = (slug: string) => {
    setSelectedCategorySlug(slug);
    setSearchKeyword('');
    setCustomerView('categories');
  };

  const handleOrderSuccess = (order: Order) => {
    setShowCheckout(false);
    setConfirmedOrder(order);
  };

  const handleTrackFromConfirmation = (orderId: string) => {
    setConfirmedOrder(null);
    setTrackingOrderId(orderId);
    setCustomerView('tracking');
  };

  // Render Customer View Content
  const renderCustomerView = () => {
    switch (customerView) {
      case 'home':
        return (
          <CustomerHome
            onOpenProductDetail={handleOpenDetail}
            onSelectCategory={handleSelectCategory}
            onSelectShop={(shopId) => {
              setCustomerView('categories');
            }}
          />
        );
      case 'categories':
      case 'search':
        return (
          <CategoryProductsView
            onOpenDetail={handleOpenDetail}
            searchKeyword={customerView === 'search' ? searchKeyword : ''}
          />
        );
      case 'cart':
        return (
          <CartView
            onProceedToCheckout={() => setShowCheckout(true)}
            onContinueShopping={() => setCustomerView('home')}
          />
        );
      case 'orders':
        return (
          <OrderHistoryView
            onSelectOrderToTrack={(id) => {
              setTrackingOrderId(id);
              setCustomerView('tracking');
            }}
            onStartShopping={() => setCustomerView('home')}
          />
        );
      case 'tracking':
        return (
          <OrderTrackingView
            orderId={trackingOrderId}
            onBackToOrders={() => setCustomerView('orders')}
          />
        );
      case 'profile':
        return (
          <CustomerProfileView
            onViewOrders={() => setCustomerView('orders')}
            onViewWishlist={() => setCustomerView('wishlist')}
          />
        );
      case 'wishlist':
        return (
          <div className="max-w-6xl mx-auto py-8 px-4 sm:px-6">
            <h1 className="text-2xl font-black text-slate-900 mb-1">Your Wishlist</h1>
            <p className="text-xs text-slate-500 mb-6">Saved favorite products</p>
            {wishlist.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8">
                <Heart className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                <h3 className="font-bold text-slate-800">Your wishlist is empty</h3>
                <p className="text-xs text-slate-400 mt-1 mb-4">Click the heart icon on any product to save it.</p>
                <button
                  onClick={() => setCustomerView('home')}
                  className="px-4 py-2 bg-[#046A38] text-white rounded-xl text-xs font-bold"
                >
                  Explore Catalog
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {wishlist.map((prod) => (
                  <div
                    key={prod.id}
                    onClick={() => handleOpenDetail(prod)}
                    className="bg-white rounded-2xl border border-slate-200 p-3 cursor-pointer shadow-2xs hover:shadow-sm transition-shadow"
                  >
                    <img src={prod.images[0]} alt="" className="aspect-square rounded-xl object-cover mb-2" />
                    <h4 className="font-bold text-xs text-slate-800 truncate">{prod.name}</h4>
                    <p className="font-bold text-sm text-[#046A38] mt-1">৳{prod.salePrice}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      case 'support':
        return <CustomerSupportView />;
      default:
        return (
          <CustomerHome
            onOpenProductDetail={handleOpenDetail}
            onSelectCategory={handleSelectCategory}
            onSelectShop={() => setCustomerView('categories')}
          />
        );
    }
  };

  const customerContent = (
    <div className="flex flex-col min-h-screen bg-[#F8FAFC]">
      <CustomerHeader
        onOpenAuth={() => setShowAuthModal(true)}
        onOpenCart={() => setCustomerView('cart')}
        onSearchChange={(q) => {
          setSearchKeyword(q);
          if (customerView !== 'search' && customerView !== 'categories') {
            setCustomerView('search');
          }
        }}
      />
      <main className="flex-1">{renderCustomerView()}</main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white border-t border-slate-800 pt-12 pb-8 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800 text-xs">
          {/* Brand Info */}
          <div className="space-y-3">
            <BrandLogo size="md" showTagline={true} />
            <p className="text-slate-400 leading-relaxed text-[11px] mt-2">
              LogeAchi.com (লগে আছি ডটকম) is Bangladesh’s leading multi-vendor e-commerce marketplace and reseller platform. Supporting authentic local crafts, fashion, and lifestyle.
            </p>
            <div className="pt-2 text-[11px] text-emerald-400 font-semibold bangla-text">
              প্রতিষ্ঠাতা ও স্বত্বাধিকারী: মোঃ রাকিব হাসান
              <br />
              Founder & Owner — LogeAchi.com
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-200 uppercase text-[11px] tracking-wider mb-2">
              Customer Services
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><button onClick={() => setCustomerView('orders')} className="hover:text-white">Track Order</button></li>
              <li><button onClick={() => setCustomerView('support')} className="hover:text-white">Rocket Payment Guide</button></li>
              <li><button onClick={() => setCustomerView('support')} className="hover:text-white">Delivery Charges (Dhaka ৳80 / Outside ৳130)</button></li>
              <li><button onClick={() => setCustomerView('support')} className="hover:text-white">Return & Refund Policy</button></li>
            </ul>
          </div>

          {/* Partner with us */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-200 uppercase text-[11px] tracking-wider mb-2">
              Earn with LogeAchi
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><button onClick={() => setShowAuthModal(true)} className="hover:text-white">Become a Verified Seller</button></li>
              <li><button onClick={() => setShowAuthModal(true)} className="hover:text-white">Join as Reseller / Dropshipper</button></li>
              <li><button onClick={() => setShowAuthModal(true)} className="hover:text-white">Build a Reseller Team</button></li>
              <li><button onClick={() => setCustomerView('support')} className="hover:text-white">Merchant Care Support</button></li>
            </ul>
          </div>

          {/* Contact & Hotline */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-200 uppercase text-[11px] tracking-wider mb-2">
              Headquarters & Contact
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Level 7, LogeAchi Tower, Green Road, Dhanmondi, Dhaka 1205, Bangladesh.
            </p>
            <p className="text-[#FF8C00] font-bold text-xs pt-1">
              Hotline: +880 1700-000000
            </p>
            <p className="text-slate-400 text-[11px]">
              Merchant Rocket: 01700-000000-8
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-6 flex flex-wrap items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © 2026 LogeAchi.com (লগে আছি ডটকম). All rights reserved. Founded by মোঃ রাকিব হাসান.
          </div>
          <div className="flex items-center gap-4">
            <span>Rocket (Featured)</span>
            <span>•</span>
            <span>bKash</span>
            <span>•</span>
            <span>Nagad</span>
            <span>•</span>
            <span>Cash on Delivery</span>
          </div>
        </div>
      </footer>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col font-sans antialiased text-slate-900 bg-slate-100">
      {/* Universal Role & Portal Switcher Top Banner */}
      <RoleSwitcherBanner />

      {/* Portal Router */}
      <div className="flex-1">
        {activePortal === 'customer' && (
          mobilePreviewMode ? (
            <MobileFrame>{customerContent}</MobileFrame>
          ) : (
            customerContent
          )
        )}

        {activePortal === 'seller' && <SellerPanel />}
        {activePortal === 'reseller' && <ResellerPanel />}
        {activePortal === 'super_admin' && <AdminPanel />}
        {activePortal === 'staff' && <AdminPanel />}
        {activePortal === 'api_docs' && <ApiDocsView />}
      </div>

      {/* Global Toast */}
      <Toast />

      {/* Modals */}
      {activeProduct && (
        <ProductDetailModal
          product={activeProduct}
          onClose={() => setActiveProduct(null)}
          onBuyNow={handleBuyNow}
        />
      )}

      {showCheckout && (
        <CheckoutModal
          onClose={() => setShowCheckout(false)}
          onOrderSuccess={handleOrderSuccess}
        />
      )}

      {confirmedOrder && (
        <OrderConfirmationModal
          order={confirmedOrder}
          onClose={() => setConfirmedOrder(null)}
          onTrackOrder={handleTrackFromConfirmation}
        />
      )}

      {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
    </div>
  );
};

export default function App() {
  return (
    <MarketplaceProvider>
      <MarketplaceApp />
    </MarketplaceProvider>
  );
}

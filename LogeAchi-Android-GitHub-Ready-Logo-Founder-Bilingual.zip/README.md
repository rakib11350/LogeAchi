# LogeAchi.com — Android App

LogeAchi.com multi-vendor e-commerce marketplace Android project.

- Package: `com.logeachi.app`
- Website: `https://logeachi.com`
- Founder: **মোঃ রাকিব হাসান**
- Title: **Owner & CEO — LogeAchi.com** / **মালিক ও প্রধান নির্বাহী কর্মকর্তা — লগে আছি ডটকম**
- The exact user-provided LogeAchi logo is included as the web/app logo and launcher icon.
- The founder profile photo is included in the in-app “About the Founder” section in both Bangla and English.
- GitHub Actions builds a real debug APK using Gradle 8.7 and Android SDK 35.

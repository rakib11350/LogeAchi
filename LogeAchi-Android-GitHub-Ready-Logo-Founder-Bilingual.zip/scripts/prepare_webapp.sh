#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/../webapp"
npm install
npm run build
rm -rf ../android/app/src/main/assets/www
mkdir -p ../android/app/src/main/assets/www
cp -R dist/* ../android/app/src/main/assets/www/
echo "Web app copied into Android assets."

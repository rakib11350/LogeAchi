@echo off
cd /d "%~dp0..\webapp"
call npm install
if errorlevel 1 exit /b 1
call npm run build
if errorlevel 1 exit /b 1
if exist "..\android\app\src\main\assets\www" rmdir /s /q "..\android\app\src\main\assets\www"
mkdir "..\android\app\src\main\assets\www"
xcopy /E /I /Y "dist\*" "..\android\app\src\main\assets\www\"
echo Web app copied into Android assets.

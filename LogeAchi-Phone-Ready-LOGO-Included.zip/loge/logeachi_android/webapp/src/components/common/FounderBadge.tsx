import React from 'react';
import { ShieldCheck, Award } from 'lucide-react';

interface FounderBadgeProps {
  compact?: boolean;
}

export const FounderBadge: React.FC<FounderBadgeProps> = ({ compact = false }) => {
  if (compact) {
    return (
      <div
        id="founder-badge-compact"
        className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-[#046A38]/10 to-[#FF6B00]/10 border border-[#046A38]/20 rounded-full text-xs text-gray-700"
      >
        <ShieldCheck className="w-3.5 h-3.5 text-[#046A38]" />
        <span className="font-medium bangla-text">প্রতিষ্ঠাতা: মোঃ রাকিব হাসান</span>
      </div>
    );
  }

  return (
    <div
      id="founder-badge-card"
      className="bg-white border border-gray-200/80 rounded-xl p-3 shadow-xs flex items-center justify-between gap-3"
    >
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-[#046A38] text-white flex items-center justify-center font-bold text-sm shrink-0 border-2 border-[#FF6B00]">
          রহ
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-sm text-gray-900 bangla-text">মোঃ রাকিব হাসান</span>
            <Award className="w-4 h-4 text-[#FF6B00]" />
          </div>
          <p className="text-xs text-gray-500">Founder & Owner — LogeAchi.com</p>
        </div>
      </div>
      <div className="text-right hidden sm:block">
        <span className="inline-block text-[11px] font-semibold text-[#046A38] bg-[#E8F5E9] px-2.5 py-0.5 rounded-full bangla-text">
          “আপনার স্বপ্ন, আমাদের সাথে—লগে আছি।”
        </span>
      </div>
    </div>
  );
};

# LogeAchi Android App

This package contains the original LogeAchi React/TypeScript marketplace plus a native Android WebView wrapper.

## Build the APK in Android Studio

1. Install **Android Studio** and make sure Android SDK 35 is installed.
2. Open the `android` folder in Android Studio.
3. Before building, build the web app and copy its `dist` output into Android assets:
   - Windows: run `scripts\\prepare_webapp.bat`
   - macOS/Linux: run `./scripts/prepare_webapp.sh`
4. If Android Studio asks to sync/download the Android Gradle Plugin, allow it.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will normally be at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Important

- This package is **not a precompiled APK**. It is the complete build project.
- No empty, 0-byte, or placeholder APK is included.
- The React app may require its `.env` values (for example Gemini/API configuration) for specific features.
- The wrapper is configured for local packaged web assets. For development, `MainActivity.java` contains a commented `10.0.2.2:5173` URL option.


## Official LogeAchi logo
The supplied official logo is included at `webapp/public/logeachi-logo.png` and is used by the in-app BrandLogo component. The launcher icon asset is at `webapp/public/logeachi-icon.png`.
